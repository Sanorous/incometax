﻿


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head><title>

	UP Government Shasanadesh(GO)-उत्तर प्रदेश सरकार के शासनादेशों की अधिकारिक वेबसाइट

</title><meta name="keywords" content="Shasanadesh UP,GO UP,Search UP GO,Gazette UP,Official Website Shasanadesh UP,E-Shasanadesh,Online GO,UP Government Order,उत्तर प्रदेश सरकार के ऑनलाइन शासनादेशों की अधिकारिक वेबसाइट" /><meta name="description" content="Search UP Government Orders Online" /><meta name="author" content="NIC" /><meta http-equiv="X-UA-Compatible" content="IE=100" />

    <script language="javascript" src="FusionCharts/FusionCharts.js" type="text/javascript"></script>



    <link href="GO/INTRA/StyleSheet.css" rel="stylesheet" type="text/css" />



    <script defer="defer" language="javascript" src="GO/JS/JScript2.js" type="text/javascript"></script>

    <meta name="google-site-verification" content="vPYDfrWbEMWz5dmnEZ8Bdsf9QfftPJRFrEXng1Sl-aY" />

 <script type="text/javascript" src="https://www.google.com/jsapi"></script>

   

    <script language="javascript" type="text/javascript">

    google.load("elements", "1", {

    packages: "transliteration"

});



function onLoad() {

    var options = {

        sourceLanguage:

                google.elements.transliteration.LanguageCode.ENGLISH,

        destinationLanguage:

                [google.elements.transliteration.LanguageCode.HINDI],

        shortcutKey: 'ctrl+g',

        transliterationEnabled: true

    };

var control =

            new google.elements.transliteration.TransliterationControl(options);



    // Enable transliteration in the editable DIV with id

    // 'transliterateDiv'.

    control.makeTransliteratable(['txtSubj']);

}

google.setOnLoadCallback(onLoad);

    </script>

   

    <script type='text/javascript'>

        function hide() {

            

            document.getElementById('Button4').style.visibility = 'hidden';



        }

        function show() {

           

            document.getElementById('Button4').style.visibility = 'visible';



        }

     </script>

     <script defer="defer" language="javascript" type="text/javascript">

              function doclear() {

             var elements = document.getElementsByTagName("input");

             for (var ii = 0; ii < elements.length; ii++) {

                 if (elements[ii].disabled == false) {

                     if (elements[ii].type == "text") {

                         elements[ii].value = '';

                     }

                     if (elements[ii].type == "textarea") {

                         elements[ii].value = '';

                     }

                     //                    if (elements[ii].type == "checkbox") {

                     //                        elements[ii].checked = false;

                     //                    }

                 }

             }

         }

        

</script>

<script language="javascript" type="text/javascript">

    function hideAge()

         {

             document.getElementById('r1').style.display = "block";

         }

         </script>

 

    

    

<script type="text/javascript" defer="defer" >

    //             function validatedate(txtbox) 

    //             {

    //                 var inputText = document.getElementById(txtbox).value

    //                 var dateformat = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/g;

    //                 // Match the date format through regular expression  

    //                 if (document.getElementById(txtbox).value.match(dateformat)) {

    //                     document.getElementById(txtbox).focus();

    //                     //Test which seperator is used '/' or '-'  

    //                     var opera1 = inputText.value.split('/');

    //                     var opera2 = inputText.value.split('-');

    //                     lopera1 = opera1.length;

    //                     lopera2 = opera2.length;

    //                     // Extract the string into month, date and year  

    //                     if (lopera1 > 1) {

    //                         var pdate = inputText.value.split('/');

    //                     }

    //                     else if (lopera2 > 1) {

    //                         var pdate = inputText.value.split('-');

    //                     }

    //                     var dd = parseInt(pdate[0]);

    //                     var mm = parseInt(pdate[1]);

    //                     var yy = parseInt(pdate[2]);

    //                     // Create list of days of a month [assume there is no leap year by default]  

    //                     var ListofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    //                     if (mm == 1 || mm > 2) {

    //                         if (dd > ListofDays[mm - 1]) {

    //                             alert('Invalid date format!');

    //                             return false;

    //                         }

    //                     }

    //                     if (mm == 2) {

    //                         var lyear = false;

    //                         if ((!(yy % 4) && yy % 100) || !(yy % 400)) {

    //                             lyear = true;

    //                         }

    //                         if ((lyear == false) && (dd >= 29)) {

    //                             alert('Invalid date format!');

    //                             return false;

    //                         }

    //                         if ((lyear == true) && (dd > 29)) {

    //                             alert('Invalid date format!');

    //                             return false;

    //                         }

    //                     }

    //                 }

    //                 else {

    //                     alert("Invalid date format!");

    //                     document.getElementById(txtbox).focus();

    //                     return false;

    //                 }

    //             }







    function validatedate(txtbox) {

        var inputText = document.getElementById(txtbox).value

        var dateformat = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/g;



        if (document.getElementById(txtbox).value.length > 0)



        // Match the date format through regular expression 



            if (document.getElementById(txtbox).value.match(dateformat)) {

                // document.getElementById(txtbox).focus();

                return true;

            }

            else {

                document.getElementById(txtbox).value = ''

                alert("कृपया तिथि dd/MM/yyyy के फॉर्मेट में भरें!");

                document.getElementById(txtbox).focus();

                return false;

            }

        {

        }





    }  











   </script>

    <script defer="defer" language="javascript" type="text/javascript">

    

       



        







        function SetButtonStatus(sender, target) {



            if (sender.value.length == 4) {

                var cap = document.getElementById("HiddenField1").value

                       if (sender.value == cap) {

                           if (document.getElementById("ddldept").value == "999")

                           {// &&  document.getElementById("txtGOdate").value == "" && document.getElementById("txtGOdate0").value == "" && document.getElementById("txtSubj").value == "" && document.getElementById("txtGOid").value == "") {

                        alert("Please select department.");//alert("Please fill atleast one criteria.")

                    }

                    else {

                        document.getElementById(target).disabled = false;



                    }

                }

                else {

                    alert("Please fill correct value.");

                }



            }

            else {

                document.getElementById(target).disabled = true;

            }

        }





    </script>



     



    <style type="text/css">

       



        .style3

        {

            font-family :Verdana;

            color: #FF0000;

            font-size :11px;

            vertical-align :top ;

        }

        .style5

         

        .tab

        {

            border: thin solid #000000;

        }

        #img2

        {

            margin-bottom: 0px;

        }

        .div1 {

    border: 2px solid;

    padding: 10px;

    background: #dddddd;

    border-bottom-left-radius: .5em;

    border-bottom-right-radius: .5em;

   border-top-left-radius :.5em;

   border-top-right-radius :.5em;

}

        .FontStyle

        {

            font-family:Verdana;

           

        }

     

        



        .style_border_left

        {

            text-align:left;

        }

        .style_border_top_left

        {

            text-align:left;

            

        }

        /*.abc

        {

             -moz-border-radius: 30px;

            -webkit-border-radius: 30px;

          border-radius:30px;

            behavior: url(border-radius.htc);

        }*/

        .div2

        {

            border-right: 1px solid black;

             border-top: 1px solid black;

        }

        #table1  td th {

    border: 1px solid green;

}

        .style_border_top

        {

             border-top: 1px solid black;

        }

         .style_border_bottom

        {

             border-bottom: 1px solid black;

        }

          .style_border_left

        {

             border-left: 1px solid black;

        }

           .style_border_right

        {

             border-right : 1px solid black;

        }

              .style_border_top_left

        {

              border-top: 1px solid black;

              border-left: 1px solid black;

        }

          

    </style>



    <script defer="defer" type="text/javascript" language="javascript">



        function funcOnClose() {

            if (window.event.clientX > 100 && window.event.clientY < 0) {

                location.href(

'MultiTabError1.aspx');

            } 

        } 



    </script>



    

        

         <style type="text/css">.modalBackground 

    #progressBackgroundFilter {

position:fixed;

top:0px;

bottom:0px;

left:0px;

right:0px;

background-color:Gray ;

overflow:hidden;

padding:0;

margin:0;

opacity:0.4;

filter:alpha(opacity=40);

z-index:1000;

}

#processMessage {

position:fixed;

top:55%;

left:42%;

width: 15%;

height:20%;

padding:10px;

background-color:#fffacd;

font-size :10pt;

z-index:1001;

font-weight:bold;

color: Maroon;



}



                    



         .style8

         {

             font-size: 9pt;

             font-family : Verdana;

             font-style: normal;

             width: 61%;

         }



           



         </style>







          



</head>

<body  style="margin-top: 0">

    <form method="post" action="./" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" autocomplete="false" class="modalBackground">

<div class="aspNetHidden">

<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />

<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />

<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />

<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUJNjc1NzQ3MTI2DxYMHgFjAgEeBGNvbnRmHhBDYXB0Y2hhSW1hZ2VUZXh0BQQ5MTUyHgRGbGFnAgIeA2R0MTK5vgEAAQAAAP////8BAAAAAAAAAAwCAAAATlN5c3RlbS5EYXRhLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OQUBAAAAFVN5c3RlbS5EYXRhLkRhdGFUYWJsZQMAAAAZRGF0YVRhYmxlLlJlbW90aW5nVmVyc2lvbglYbWxTY2hlbWELWG1sRGlmZkdyYW0DAQEOU3lzdGVtLlZlcnNpb24CAAAACQMAAAAGBAAAAJkHPD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTE2Ij8+DQo8eHM6c2NoZW1hIHhtbG5zPSIiIHhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIgeG1sbnM6bXNkYXRhPSJ1cm46c2NoZW1hcy1taWNyb3NvZnQtY29tOnhtbC1tc2RhdGEiPg0KICA8eHM6ZWxlbWVudCBuYW1lPSJ0YmxEZXB0MSI+DQogICAgPHhzOmNvbXBsZXhUeXBlPg0KICAgICAgPHhzOnNlcXVlbmNlPg0KICAgICAgICA8eHM6ZWxlbWVudCBuYW1lPSJzbm8iIHR5cGU9InhzOmxvbmciIG1zZGF0YTp0YXJnZXROYW1lc3BhY2U9IiIgbWluT2NjdXJzPSIwIiAvPg0KICAgICAgICA8eHM6ZWxlbWVudCBuYW1lPSJEZXB0TmFtZSIgdHlwZT0ieHM6c3RyaW5nIiBtc2RhdGE6dGFyZ2V0TmFtZXNwYWNlPSIiIG1pbk9jY3Vycz0iMCIgLz4NCiAgICAgICAgPHhzOmVsZW1lbnQgbmFtZT0iVENvdW50IiB0eXBlPSJ4czppbnQiIG1zZGF0YTp0YXJnZXROYW1lc3BhY2U9IiIgbWluT2NjdXJzPSIwIiAvPg0KICAgICAgICA8eHM6ZWxlbWVudCBuYW1lPSJkZXB0Y29kZSIgdHlwZT0ieHM6aW50IiBtc2RhdGE6dGFyZ2V0TmFtZXNwYWNlPSIiIG1pbk9jY3Vycz0iMCIgLz4NCiAgICAgIDwveHM6c2VxdWVuY2U+DQogICAgPC94czpjb21wbGV4VHlwZT4NCiAgPC94czplbGVtZW50Pg0KICA8eHM6ZWxlbWVudCBuYW1lPSJOZXdEYXRhU2V0IiBtc2RhdGE6SXNEYXRhU2V0PSJ0cnVlIiBtc2RhdGE6TWFpbkRhdGFUYWJsZT0idGJsRGVwdDEiIG1zZGF0YTpVc2VDdXJyZW50TG9jYWxlPSJ0cnVlIj4NCiAgICA8eHM6Y29tcGxleFR5cGU+DQogICAgICA8eHM6Y2hvaWNlIG1pbk9jY3Vycz0iMCIgbWF4T2NjdXJzPSJ1bmJvdW5kZWQiIC8+DQogICAgPC94czpjb21wbGV4VHlwZT4NCiAgPC94czplbGVtZW50Pg0KPC94czpzY2hlbWE+BgUAAADytAE8ZGlmZmdyOmRpZmZncmFtIHhtbG5zOm1zZGF0YT0idXJuOnNjaGVtYXMtbWljcm9zb2Z0LWNvbTp4bWwtbXNkYXRhIiB4bWxuczpkaWZmZ3I9InVybjpzY2hlbWFzLW1pY3Jvc29mdC1jb206eG1sLWRpZmZncmFtLXYxIj4NCiAgPE5ld0RhdGFTZXQ+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDExIiBtc2RhdGE6cm93T3JkZXI9IjAiPg0KICAgICAgPHNubz4xPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSF4KSk4KS/4KSw4KS/4KSV4KWN4oCN4KSkIOCkiuCksOCljeCknOCkviDgpLbgpY3gpLDgpYvgpKQg4KS14KS/4KSt4KS+4KSXIDwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjE1ODwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE3NjwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTIiIG1zZGF0YTpyb3dPcmRlcj0iMSI+DQogICAgICA8c25vPjI8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpIXgpLLgpY3igI3gpKrgpLjgpILgpJbgpY3igI3gpK/gpJUg4KSV4KSy4KWN4oCN4KSv4KS+4KSjIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjQ3MDwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjY0PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMyIgbXNkYXRhOnJvd09yZGVyPSIyIj4NCiAgICAgIDxzbm8+Mzwvc25vPg0KICAgICAgPERlcHROYW1lPuCkheCkteCkuOCljeCkpeCkvuCkquCkqOCkviDgpLXgpL/gpJXgpL7gpLgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MjE8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xODE8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE0IiBtc2RhdGE6cm93T3JkZXI9IjMiPg0KICAgICAgPHNubz40PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSG4KSs4KSV4KS+4KSw4KWAIOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4zMzc8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xOTwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTUiIG1zZGF0YTpyb3dPcmRlcj0iNCI+DQogICAgICA8c25vPjU8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpIbgpLXgpL7gpLgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+NzIxPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTg2PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNiIgbXNkYXRhOnJvd09yZGVyPSI1Ij4NCiAgICAgIDxzbm8+Njwvc25vPg0KICAgICAgPERlcHROYW1lPuCkieCkmuCljeKAjeCkmiDgpLbgpL/gpJXgpY3gpLfgpL4g4KS14KS/4KSt4KS+4KSXIDwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjI1ODwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE2NzwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTciIG1zZGF0YTpyb3dPcmRlcj0iNiI+DQogICAgICA8c25vPjc8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpIngpKTgpY3igI3gpKTgpLAg4KSq4KWN4KSw4KSm4KWH4KS2IOCkquClgeCkqOCksOCljeCkl+CkoOCkqCDgpLjgpK7gpKjgpY3igI3gpLXgpK8g4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MTg8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4yMDM8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE4IiBtc2RhdGE6cm93T3JkZXI9IjciPg0KICAgICAgPHNubz44PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSJ4KSm4KWN4KSv4KS+4KSoIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjI3MzwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjc0PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxOSIgbXNkYXRhOnJvd09yZGVyPSI4Ij4NCiAgICAgIDxzbm8+OTwvc25vPg0KICAgICAgPERlcHROYW1lPuCkieCkquCkreCli+CkleCljeKAjeCkpOCkviDgpLjgpILgpLDgpJXgpY3gpLfgpKMg4KSP4KS14KSCIOCkrOCkvuCknyDgpK7gpL7gpKog4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+Nzc1PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MjEzPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMTAiIG1zZGF0YTpyb3dPcmRlcj0iOSI+DQogICAgICA8c25vPjEwPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSK4KSw4KWN4KSc4KS+IOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjMyMDwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDExMSIgbXNkYXRhOnJvd09yZGVyPSIxMCI+DQogICAgICA8c25vPjExPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSP4KSoLuCkhuCksC7gpIbgpIggIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjE8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4yMTg8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDExMiIgbXNkYXRhOnJvd09yZGVyPSIxMSI+DQogICAgICA8c25vPjEyPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSU4KSm4KWN4KSv4KWL4KSX4KS/4KSVIOCkteCkv+CkleCkvuCkuCDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4yNjY8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xODI8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDExMyIgbXNkYXRhOnJvd09yZGVyPSIxMiI+DQogICAgICA8c25vPjEzPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSV4KWD4KS34KS/IOCkteCkv+CkquCko+CkqCDgpI/gpLXgpIIg4KS14KS/4KSm4KWH4KS2IOCkteCljeKAjeCkr+CkvuCkquCkvuCksCDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xMjg8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xMDI8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDExNCIgbXNkYXRhOnJvd09yZGVyPSIxMyI+DQogICAgICA8c25vPjE0PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSV4KWD4KS34KS/IOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjM4ODwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjM3PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMTUiIG1zZGF0YTpyb3dPcmRlcj0iMTQiPg0KICAgICAgPHNubz4xNTwvc25vPg0KICAgICAgPERlcHROYW1lPuCkleClg+Ckt+CkvyDgpLbgpL/gpJXgpY3gpLfgpL4g4KSP4KS14KSCIOCkheCkqOClgeCkuOCkguCkp+CkvuCkqCDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD45MDwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjM5PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMTYiIG1zZGF0YTpyb3dPcmRlcj0iMTUiPg0KICAgICAgPHNubz4xNjwvc25vPg0KICAgICAgPERlcHROYW1lPuCkleCkvuCksOCljeCkruCkv+CklSDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD44MDc8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xNjM8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDExNyIgbXNkYXRhOnJvd09yZGVyPSIxNiI+DQogICAgICA8c25vPjE3PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSV4KS+4KSw4KWN4KSv4KSV4KWN4KSw4KSuIOCkleCkvuCksOCljeCkr+CkvuCkqOCljeCkteCkr+CkqCDgpLXgpL/gpK3gpL7gpJcgPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MzM8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xOTE8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDExOCIgbXNkYXRhOnJvd09yZGVyPSIxNyI+DQogICAgICA8c25vPjE4PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSV4KS+4KSw4KS+4KSX4KS+4KSwIOCkquCljeCksOCktuCkvuCkuOCkqCDgpI/gpLXgpIIg4KS44KWB4KSn4KS+4KSwIOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xNjY4PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTU8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDExOSIgbXNkYXRhOnJvd09yZGVyPSIxOCI+DQogICAgICA8c25vPjE5PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSW4KWH4KSyIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjE3OTwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjIwODwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTIwIiBtc2RhdGE6cm93T3JkZXI9IjE5Ij4NCiAgICAgIDxzbm8+MjA8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpJbgpL7gpKbgpY3gpK8g4KSP4KS14KSCIOCklOCkt+Ckp+CkvyDgpKrgpY3gpLDgpLbgpL7gpLjgpKgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MjcwPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MjAyPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMjEiIG1zZGF0YTpyb3dPcmRlcj0iMjAiPg0KICAgICAgPHNubz4yMTwvc25vPg0KICAgICAgPERlcHROYW1lPuCkluCkvuCkpuCljeCkryDgpI/gpLXgpK7gpY0g4KSw4KS44KSmIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjIwNTM8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4zODwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTIyIiBtc2RhdGE6cm93T3JkZXI9IjIxIj4NCiAgICAgIDxzbm8+MjI8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpJbgpL7gpKbgpYAg4KSP4KS14KSCIOCkl+CljeCksOCkvuCkruCli+CkpuCljeCkr+Cli+CklyDgpLXgpL/gpK3gpL7gpJcgPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MTIxPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTY4PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMjMiIG1zZGF0YTpyb3dPcmRlcj0iMjIiPg0KICAgICAgPHNubz4yMzwvc25vPg0KICAgICAgPERlcHROYW1lPuCkl+CljeCksOCkvuCkruCljeCkryDgpLXgpL/gpJXgpL7gpLgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MTI0OTwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjQwPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMjQiIG1zZGF0YTpyb3dPcmRlcj0iMjMiPg0KICAgICAgPHNubz4yNDwvc25vPg0KICAgICAgPERlcHROYW1lPuCkl+CljeCksOCkvuCkruClgOCkoyDgpIXgpK3gpL/gpK/gpKjgpY3igI3gpKTgpY3gpLDgpKMg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MzE2PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+NDc8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDEyNSIgbXNkYXRhOnJvd09yZGVyPSIyNCI+DQogICAgICA8c25vPjI1PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSX4KWD4KS5IOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xMjY0PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTY1PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMjYiIG1zZGF0YTpyb3dPcmRlcj0iMjUiPg0KICAgICAgPHNubz4yNjwvc25vPg0KICAgICAgPERlcHROYW1lPuCkl+Cli+CkquCkqCDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD41PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MjE1PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMjciIG1zZGF0YTpyb3dPcmRlcj0iMjYiPg0KICAgICAgPHNubz4yNzwvc25vPg0KICAgICAgPERlcHROYW1lPuCkmuCkv+CkleCkv+CkpOCljeKAjeCkuOCkviDgpI/gpLXgpIIg4KS44KWN4oCN4KS14KS+4KS44KWN4oCN4KSlIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjIwNTU8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4yMDE8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDEyOCIgbXNkYXRhOnJvd09yZGVyPSIyNyI+DQogICAgICA8c25vPjI4PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSa4KS/4KSV4KS/4KSk4KWN4oCN4KS44KS+IOCktuCkv+CkleCljeCkt+CkviDgpI/gpLXgpIIg4KSG4KSv4KWB4KS3IOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD44MjE8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4yNTwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTI5IiBtc2RhdGE6cm93T3JkZXI9IjI4Ij4NCiAgICAgIDxzbm8+Mjk8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpJrgpYDgpKjgpYAg4KSJ4KSm4KWN4KSv4KWL4KSXIOCkj+CkteCkgiDgpJfgpKjgpY3igI3gpKjgpL4g4KS14KS/4KSV4KS+4KS4IOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjE0ODwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjk8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDEzMCIgbXNkYXRhOnJvd09yZGVyPSIyOSI+DQogICAgICA8c25vPjMwPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSm4KWB4KSX4KWN4KSnIOCkteCkv+CkleCkvuCkuCDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD42MzwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE0MjwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTMxIiBtc2RhdGE6cm93T3JkZXI9IjMwIj4NCiAgICAgIDxzbm8+MzE8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpKfgpLDgpY3gpK7gpL7gpLDgpY3gpKUg4KSV4KS+4KSw4KWN4KSvICA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4zODwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE5MzwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTMyIiBtc2RhdGE6cm93T3JkZXI9IjMxIj4NCiAgICAgIDxzbm8+MzI8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpKjgpJfgpLAg4KS14KS/4KSV4KS+4KS4IOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjE1MzU8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xNzA8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDEzMyIgbXNkYXRhOnJvd09yZGVyPSIzMiI+DQogICAgICA8c25vPjMzPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSo4KSX4KSw4KWA4KSvIOCksOCli+CknOCkl+CkvuCksCDgpI/gpLXgpIIg4KSX4KSw4KWA4KSs4KWAIOCkieCkqOCljeKAjeCkruClguCksuCkqCDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xNzg4PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MjExPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMzQiIG1zZGF0YTpyb3dPcmRlcj0iMzMiPg0KICAgICAgPHNubz4zNDwvc25vPg0KICAgICAgPERlcHROYW1lPuCkqOCljeCkr+CkvuCkryDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xMDQxPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+NDY8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDEzNSIgbXNkYXRhOnJvd09yZGVyPSIzNCI+DQogICAgICA8c25vPjM1PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSo4KS+4KSX4KSw4KS/4KSVIOCkieCkoeCljeCkoeCkvOCkr+CkqCDgpLXgpL/gpK3gpL7gpJcgPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MTkzPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+NjwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTM2IiBtc2RhdGE6cm93T3JkZXI9IjM1Ij4NCiAgICAgIDxzbm8+MzY8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpKjgpL7gpJfgpLDgpL/gpJUg4KS44KWB4KSw4KSV4KWN4KS34KS+IOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4yNDwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjk3PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxMzciIG1zZGF0YTpyb3dPcmRlcj0iMzYiPg0KICAgICAgPHNubz4zNzwvc25vPg0KICAgICAgPERlcHROYW1lPuCkqOCkv+CknOClgCDgpKrgpYLgpILgpJzgpYAg4KSo4KS/4KS14KWH4KS2IOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjA8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4yMTI8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDEzOCIgbXNkYXRhOnJvd09yZGVyPSIzNyI+DQogICAgICA8c25vPjM4PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSo4KS/4KSv4KWB4KSV4KWN4KSk4KS/IOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD42MTE8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xNzQ8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDEzOSIgbXNkYXRhOnJvd09yZGVyPSIzOCI+DQogICAgICA8c25vPjM5PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSo4KS/4KSv4KWL4KSc4KSoIOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xMDQyPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+NTQ8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE0MCIgbXNkYXRhOnJvd09yZGVyPSIzOSI+DQogICAgICA8c25vPjQwPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSo4KS/4KSw4KWN4KS14KS+4KSa4KSoIOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD40MjwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE5MjwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTQxIiBtc2RhdGE6cm93T3JkZXI9IjQwIj4NCiAgICAgIDxzbm8+NDE8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpKrgpILgpJrgpL7gpK/gpKTgpYDgpLDgpL7gpJwg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+NDg5PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+ODA8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE0MiIgbXNkYXRhOnJvd09yZGVyPSI0MSI+DQogICAgICA8c25vPjQyPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSq4KSw4KSk4KWAIOCkreClguCkruCkvyDgpLXgpL/gpJXgpL7gpLgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+Mzc8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xNDc8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE0MyIgbXNkYXRhOnJvd09yZGVyPSI0MiI+DQogICAgICA8c25vPjQzPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSq4KSw4KWN4KSv4KSf4KSoIOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4zNTU8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT43PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNDQiIG1zZGF0YTpyb3dPcmRlcj0iNDMiPg0KICAgICAgPHNubz40NDwvc25vPg0KICAgICAgPERlcHROYW1lPuCkquCksOCljeCkr+CkvuCkteCksOCkoyDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4zMDwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE1NzwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTQ1IiBtc2RhdGE6cm93T3JkZXI9IjQ0Ij4NCiAgICAgIDxzbm8+NDU8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpKrgpY3gpLDgpLbgpL7gpLjgpKjgpL/gpJUg4KS44KWB4KSn4KS+4KSwIOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xNzA8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT42MTwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTQ2IiBtc2RhdGE6cm93T3JkZXI9IjQ1Ij4NCiAgICAgIDxzbm8+NDY8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpKrgpY3gpLDgpL7gpLXgpL/gpKfgpL/gpJUg4KS24KS/4KSV4KWN4KS34KS+IOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD41NTA8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xMjwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTQ3IiBtc2RhdGE6cm93T3JkZXI9IjQ2Ij4NCiAgICAgIDxzbm8+NDc8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpKrgpLDgpL/gpLXgpLngpKgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+NDg0PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MjM8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE0OCIgbXNkYXRhOnJvd09yZGVyPSI0NyI+DQogICAgICA8c25vPjQ4PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSq4KWN4KSw4KWL4KSf4KWL4KSV4KS+4KSyIOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xNTA8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xODM8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE0OSIgbXNkYXRhOnJvd09yZGVyPSI0OCI+DQogICAgICA8c25vPjQ5PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSq4KS24KWB4KSn4KSoIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjMxODwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjQxPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNTAiIG1zZGF0YTpyb3dPcmRlcj0iNDkiPg0KICAgICAgPHNubz41MDwvc25vPg0KICAgICAgPERlcHROYW1lPuCkquCkv+Ckm+CkoeCkvOCkviDgpLXgpLDgpY3gpJcg4KSV4KSy4KWN4oCN4KSv4KS+4KSjIOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD45NzwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjIwPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNTEiIG1zZGF0YTpyb3dPcmRlcj0iNTAiPg0KICAgICAgPHNubz41MTwvc25vPg0KICAgICAgPERlcHROYW1lPuCkrOCliOCkleCkv+CkguCklyDgpLXgpL/gpK3gpL7gpJcgPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MDwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE5OTwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTUyIiBtc2RhdGE6cm93T3JkZXI9IjUxIj4NCiAgICAgIDxzbm8+NTI8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpK3gpYLgpKTgpKTgpY3igI3gpLUg4KSP4KS14KSCIOCkluCkqOCkv+CkleCksOCljeCkriDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD42NTwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjIxNDwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTUzIiBtc2RhdGE6cm93T3JkZXI9IjUyIj4NCiAgICAgIDxzbm8+NTM8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpK3gpL7gpLfgpL4g4KS14KS/4KSt4KS+4KSXIDwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjEwMTwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjYzPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNTQiIG1zZGF0YTpyb3dPcmRlcj0iNTMiPg0KICAgICAgPHNubz41NDwvc25vPg0KICAgICAgPERlcHROYW1lPuCkruClgeCkluCljeKAjeCkr+CkruCkguCkpOCljeCksOClgCDgpJXgpL7gpLDgpY3gpK/gpL7gpLLgpK8g4KSy4KWL4KSVIOCktuCkv+CkleCkvuCkr+CkpCDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xODwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjIxNzwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTU1IiBtc2RhdGE6cm93T3JkZXI9IjU0Ij4NCiAgICAgIDxzbm8+NTU8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpK7gpKTgpY3igI3gpLjgpY3igI3gpK8g4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+OTA8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT40NDwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTU2IiBtc2RhdGE6cm93T3JkZXI9IjU1Ij4NCiAgICAgIDxzbm8+NTY8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpK7gpLngpL/gpLLgpL4g4KSP4KS14KSCIOCkrOCkvuCksiDgpLXgpL/gpJXgpL7gpLgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MjE0PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTE2PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNTciIG1zZGF0YTpyb3dPcmRlcj0iNTYiPg0KICAgICAgPHNubz41Nzwvc25vPg0KICAgICAgPERlcHROYW1lPuCkr+ClgeCkteCkviDgpJXgpLLgpY3gpK/gpL7gpKMg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MTc8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xMTE8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE1OCIgbXNkYXRhOnJvd09yZGVyPSI1NyI+DQogICAgICA8c25vPjU4PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KSw4KWH4KS24KSuIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjgxPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTQ1PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNTkiIG1zZGF0YTpyb3dPcmRlcj0iNTgiPg0KICAgICAgPHNubz41OTwvc25vPg0KICAgICAgPERlcHROYW1lPuCksOCkvuCknOCkqOCliOCkpOCkv+CklSDgpKrgpYfgpILgpLbgpKgg4KS14KS/4KSt4KS+4KSXIDwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjkyPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTk4PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNjAiIG1zZGF0YTpyb3dPcmRlcj0iNTkiPg0KICAgICAgPHNubz42MDwvc25vPg0KICAgICAgPERlcHROYW1lPuCksOCkvuCknOCljeCkryDgpK/gpYvgpJzgpKjgpL4g4KSG4KSv4KWL4KSXIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjYxPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MjwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTYxIiBtc2RhdGE6cm93T3JkZXI9IjYwIj4NCiAgICAgIDxzbm8+NjE8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLDgpL7gpJzgpY3gpK8g4KS44KSu4KWN4KSq4KSk4KWN4KSk4KS/PC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MTgwMzwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE3MTwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTYyIiBtc2RhdGE6cm93T3JkZXI9IjYxIj4NCiAgICAgIDxzbm8+NjI8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLDgpL7gpJzgpLjgpY3igI3gpLUg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MjA2NTwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE3NTwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTYzIiBtc2RhdGE6cm93T3JkZXI9IjYyIj4NCiAgICAgIDxzbm8+NjM8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLDgpL7gpLfgpY3igI3gpJ/gpY3gpLDgpYDgpK8g4KSP4KSV4KWA4KSV4KSw4KSjIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjY4PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MjA3PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNjQiIG1zZGF0YTpyb3dPcmRlcj0iNjMiPg0KICAgICAgPHNubz42NDwvc25vPg0KICAgICAgPERlcHROYW1lPuCksuCkmOClgSDgpLjgpL/gpILgpJrgpL7gpIgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+NDUwPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTEwPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNjUiIG1zZGF0YTpyb3dPcmRlcj0iNjQiPg0KICAgICAgPHNubz42NTwvc25vPg0KICAgICAgPERlcHROYW1lPuCksuCli+CklSDgpKjgpL/gpLDgpY3gpK7gpL7gpKMg4KS14KS/4KSt4KS+4KSXIDwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjQ5Mjg8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4zNDwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTY2IiBtc2RhdGE6cm93T3JkZXI9IjY1Ij4NCiAgICAgIDxzbm8+NjY8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLLgpYvgpJUg4KS44KWH4KS14KS+IOCkquCljeCksOCkrOCkguCkp+CkqCDgpLXgpL/gpK3gpL7gpJcgPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+NDwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjIwNDwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTY3IiBtc2RhdGE6cm93T3JkZXI9IjY2Ij4NCiAgICAgIDxzbm8+Njc8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLXgpKgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+ODgxPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MzU8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE2OCIgbXNkYXRhOnJvd09yZGVyPSI2NyI+DQogICAgICA8c25vPjY4PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS14KWN4oCN4KSv4KS14KS44KS+4KSv4KS/4KSVIOCktuCkv+CkleCljeCkt+CkviDgpI/gpLXgpIIg4KSV4KWM4KS24KSyIOCkteCkv+CkleCkvuCkuCDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD42NzY8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xODA8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE2OSIgbXNkYXRhOnJvd09yZGVyPSI2OCI+DQogICAgICA8c25vPjY5PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS14KS44KWN4oCN4KSk4KWN4KSw4KWL4KSm4KWN4KSv4KWL4KSXIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50Pjg4PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTQ2PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNzAiIG1zZGF0YTpyb3dPcmRlcj0iNjkiPg0KICAgICAgPHNubz43MDwvc25vPg0KICAgICAgPERlcHROYW1lPuCkteCkvuCkueCkryDgpLjgpL7gpLngpL7gpK/gpKTgpL/gpJUg4KSq4KSw4KS/4KSv4KWL4KSc4KSo4KS+IDwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjI3PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTIwPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNzEiIG1zZGF0YTpyb3dPcmRlcj0iNzAiPg0KICAgICAgPHNubz43MTwvc25vPg0KICAgICAgPERlcHROYW1lPuCkteCkv+CkleCksuCkvuCkguCklyDgpJXgpLLgpY3gpK/gpL7gpKMg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+OTY4PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTE4PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNzIiIG1zZGF0YTpyb3dPcmRlcj0iNzEiPg0KICAgICAgPHNubz43Mjwvc25vPg0KICAgICAgPERlcHROYW1lPuCkteCkv+CknOCljeCknuCkvuCkqCDgpI/gpLXgpIIg4KSq4KWN4KSw4KWL4KSm4KWN4KSv4KWL4KSX4KS/4KSV4KWAIOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xMTY8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xMDA8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE3MyIgbXNkYXRhOnJvd09yZGVyPSI3MiI+DQogICAgICA8c25vPjczPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS14KS/4KSk4KWN4oCN4KSkIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjExOTk8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xNjI8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE3NCIgbXNkYXRhOnJvd09yZGVyPSI3MyI+DQogICAgICA8c25vPjc0PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS14KS/4KSn4KS+4KSv4KWAIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjI8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xODk8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE3NSIgbXNkYXRhOnJvd09yZGVyPSI3NCI+DQogICAgICA8c25vPjc1PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS24KWN4KSw4KSuIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjQ0NjwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjIxPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNzYiIG1zZGF0YTpyb3dPcmRlcj0iNzUiPg0KICAgICAgPHNubz43Njwvc25vPg0KICAgICAgPERlcHROYW1lPuCktuCkv+CkleCljeCkt+CkviDgpLXgpL/gpK3gpL7gpJc8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4xMzMyPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTczPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNzciIG1zZGF0YTpyb3dPcmRlcj0iNzYiPg0KICAgICAgPHNubz43Nzwvc25vPg0KICAgICAgPERlcHROYW1lPuCkuOClguCkleCljeCkt+CljeCkrizgpLLgpJjgpYEg4KSP4KS14KSCIOCkruCkp+CljeCkr+CkriDgpIngpKbgpY3gpK/gpK4g4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MTIxPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTY2PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxNzgiIG1zZGF0YTpyb3dPcmRlcj0iNzciPg0KICAgICAgPHNubz43ODwvc25vPg0KICAgICAgPERlcHROYW1lPuCkuOClguCkmuCkqOCkviDgpI/gpLXgpIIg4KSq4KWN4KSw4KWM4KSm4KWN4KSv4KWL4KSX4KS/4KSV4KWAIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjQ0MTwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE4ODwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTc5IiBtc2RhdGE6cm93T3JkZXI9Ijc4Ij4NCiAgICAgIDxzbm8+Nzk8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLjgpYLgpJrgpKjgpL4g4KS14KS/4KSt4KS+4KSXIDwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjQzPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+Nzk8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE4MCIgbXNkYXRhOnJvd09yZGVyPSI3OSI+DQogICAgICA8c25vPjgwPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS44KSa4KS/4KS14KS+4KSy4KSvIOCkquCljeCksOCktuCkvuCkuOCkqCDgpLXgpL/gpK3gpL7gpJcgPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MzkwPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MzY8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE4MSIgbXNkYXRhOnJvd09yZGVyPSI4MCI+DQogICAgICA8c25vPjgxPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS44KWN4KSf4KS+4KSu4KWN4KSqIOCkj+CkteCkgiDgpLDgpJzgpL/gpLjgpY3gpJ/gpY3gpLDgpYfgpLbgpKgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MTAwPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+OTQ8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE4MiIgbXNkYXRhOnJvd09yZGVyPSI4MSI+DQogICAgICA8c25vPjgyPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS44KSk4KSw4KWN4KSV4KSk4KS+IOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjE0PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTUwPC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxODMiIG1zZGF0YTpyb3dPcmRlcj0iODIiPg0KICAgICAgPHNubz44Mzwvc25vPg0KICAgICAgPERlcHROYW1lPuCkuOCliOCkqOCkv+CklSDgpJXgpLLgpY3igI3gpK/gpL7gpKMg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+NzU8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4yMDk8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE4NCIgbXNkYXRhOnJvd09yZGVyPSI4MyI+DQogICAgICA8c25vPjg0PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS44KSu4KSX4KWN4KSwIOCkl+CljeCksOCkvuCkruCljeKAjeCkryDgpLXgpL/gpJXgpL7gpLgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MTU8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4yMTA8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE4NSIgbXNkYXRhOnJvd09yZGVyPSI4NCI+DQogICAgICA8c25vPjg1PC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS44KSu4KSo4KWN4KS14KSvIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjI2PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTg0PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxODYiIG1zZGF0YTpyb3dPcmRlcj0iODUiPg0KICAgICAgPHNubz44Njwvc25vPg0KICAgICAgPERlcHROYW1lPuCkuOCkruCkvuCknCDgpJXgpLLgpY3gpK/gpL7gpKMg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+NzYxPC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+MTA3PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxODciIG1zZGF0YTpyb3dPcmRlcj0iODYiPg0KICAgICAgPHNubz44Nzwvc25vPg0KICAgICAgPERlcHROYW1lPuCkuOCljeKAjeCkteCkpOCkqOCljeKAjeCkpOCljeCksOCkpOCkviDgpLjgpILgpJfgpY3gpLDgpL7gpK4g4KS44KWH4KSo4KS+4KSo4KWAIOCkleCksuCljeKAjeCkr+CkvuCkoyDgpKrgpLDgpL/gpLfgpKYg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+OTwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjIwNjwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTg4IiBtc2RhdGE6cm93T3JkZXI9Ijg3Ij4NCiAgICAgIDxzbm8+ODg8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLjgpILgpLjgpY3igI3gpKXgpL7gpJfgpKQg4KS14KS/4KSk4KWN4oCN4KSkIOCkleCksCDgpI/gpLXgpIIg4KSo4KS/4KSs4KSo4KWN4oCN4KSn4KSoIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjI1MDwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE5NjwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTg5IiBtc2RhdGE6cm93T3JkZXI9Ijg4Ij4NCiAgICAgIDxzbm8+ODk8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLjgpILgpLjgpKbgpYDgpK8g4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+NDwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE4NTwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTkwIiBtc2RhdGE6cm93T3JkZXI9Ijg5Ij4NCiAgICAgIDxzbm8+OTA8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLjgpLngpJXgpL7gpLDgpL/gpKTgpL4gIOCkteCkv+CkreCkvuCklzwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjEwNjwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE2PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICAgIDx0YmxEZXB0MSBkaWZmZ3I6aWQ9InRibERlcHQxOTEiIG1zZGF0YTpyb3dPcmRlcj0iOTAiPg0KICAgICAgPHNubz45MTwvc25vPg0KICAgICAgPERlcHROYW1lPuCkuOCkvuCkruCkvuCkqOCljeKAjeCkryDgpKrgpY3gpLDgpLbgpL7gpLjgpKgg4KS14KS/4KSt4KS+4KSXIDwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjI1PC9UQ291bnQ+DQogICAgICA8ZGVwdGNvZGU+NDg8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE5MiIgbXNkYXRhOnJvd09yZGVyPSI5MSI+DQogICAgICA8c25vPjkyPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS44KS+4KSw4KWN4KS14KSc4KSo4KS/4KSVIOCkieCkpuCljeCkr+CkriDgpLXgpL/gpK3gpL7gpJcgPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+NTk8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT4xNjE8L2RlcHRjb2RlPg0KICAgIDwvdGJsRGVwdDE+DQogICAgPHRibERlcHQxIGRpZmZncjppZD0idGJsRGVwdDE5MyIgbXNkYXRhOnJvd09yZGVyPSI5MiI+DQogICAgICA8c25vPjkzPC9zbm8+DQogICAgICA8RGVwdE5hbWU+4KS44KS+4KSC4KS44KWN4oCN4KSV4KWD4KSk4KS/IOCkteCkv+CkreCkvuCklyA8L0RlcHROYW1lPg0KICAgICAgPFRDb3VudD4yNjE8L1RDb3VudD4NCiAgICAgIDxkZXB0Y29kZT42NTwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTk0IiBtc2RhdGE6cm93T3JkZXI9IjkzIj4NCiAgICAgIDxzbm8+OTQ8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLjgpL/gpILgpJrgpL7gpIgg4KSP4KS14KSCIOCknOCksiDgpLjgpILgpLjgpL7gpKfgpKgg4KS14KS/4KSt4KS+4KSXPC9EZXB0TmFtZT4NCiAgICAgIDxUQ291bnQ+MjgwNzwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE4NzwvZGVwdGNvZGU+DQogICAgPC90YmxEZXB0MT4NCiAgICA8dGJsRGVwdDEgZGlmZmdyOmlkPSJ0YmxEZXB0MTk1IiBtc2RhdGE6cm93T3JkZXI9Ijk0Ij4NCiAgICAgIDxzbm8+OTU8L3Nubz4NCiAgICAgIDxEZXB0TmFtZT7gpLngpYvgpK7gpJfgpL7gpKHgpLDgpY3gpLgg4KS14KS/4KSt4KS+4KSXIDwvRGVwdE5hbWU+DQogICAgICA8VENvdW50PjE4NTwvVENvdW50Pg0KICAgICAgPGRlcHRjb2RlPjE3PC9kZXB0Y29kZT4NCiAgICA8L3RibERlcHQxPg0KICA8L05ld0RhdGFTZXQ+DQo8L2RpZmZncjpkaWZmZ3JhbT4EAwAAAA5TeXN0ZW0uVmVyc2lvbgQAAAAGX01ham9yBl9NaW5vcgZfQnVpbGQJX1JldmlzaW9uAAAAAAgICAgCAAAAAAAAAP//////////Cx4GdXBkYXRlBR05JTJmMjIlMmYyMDE2KzEyJTNhMDclM2ExMitBTRYCAgMPZBYIAgQPZBYCZg9kFgICAQ8PFgIeBFRleHQFKk5vLiBvZiBTZWFyY2hlcyAmIEdPJ3MgZG93bmxvYWRlZDotNjk0MzM5MmRkAgUPZBYCZg9kFgYCAw8QDxYGHg1EYXRhVGV4dEZpZWxkBQVjbmFtZR4ORGF0YVZhbHVlRmllbGQFCGRlcHRjb2RlHgtfIURhdGFCb3VuZGdkEBVgH+CkuOCkruCkuOCljeCkpCDgpLXgpL/gpK3gpL7gpJdM4KSF4KSk4KS/4KSw4KS/4KSV4KWN4oCN4KSkIOCkiuCksOCljeCknOCkviDgpLbgpY3gpLDgpYvgpKQg4KS14KS/4KSt4KS+4KSXIErgpIXgpLLgpY3igI3gpKrgpLjgpILgpJbgpY3igI3gpK/gpJUg4KSV4KSy4KWN4oCN4KSv4KS+4KSjIOCkteCkv+CkreCkvuCklzvgpIXgpLXgpLjgpY3gpKXgpL7gpKrgpKjgpL4g4KS14KS/4KSV4KS+4KS4IOCkteCkv+CkreCkvuCklyPgpIbgpKzgpJXgpL7gpLDgpYAg4KS14KS/4KSt4KS+4KSXIBzgpIbgpLXgpL7gpLgg4KS14KS/4KSt4KS+4KSXM+CkieCkmuCljeKAjeCkmiDgpLbgpL/gpJXgpY3gpLfgpL4g4KS14KS/4KSt4KS+4KSXIGTgpIngpKTgpY3igI3gpKTgpLAg4KSq4KWN4KSw4KSm4KWH4KS2IOCkquClgeCkqOCksOCljeCkl+CkoOCkqCDgpLjgpK7gpKjgpY3igI3gpLXgpK8g4KS14KS/4KSt4KS+4KSXIuCkieCkpuCljeCkr+CkvuCkqCDgpLXgpL/gpK3gpL7gpJdf4KSJ4KSq4KSt4KWL4KSV4KWN4oCN4KSk4KS+IOCkuOCkguCksOCkleCljeCkt+CkoyDgpI/gpLXgpIIg4KSs4KS+4KSfIOCkruCkvuCkqiDgpLXgpL/gpK3gpL7gpJcf4KSK4KSw4KWN4KSc4KS+IOCkteCkv+CkreCkvuCklyXgpI/gpKgu4KSG4KSwLuCkhuCkiCAg4KS14KS/4KSt4KS+4KSXOOCklOCkpuCljeCkr+Cli+Ckl+Ckv+CklSDgpLXgpL/gpJXgpL7gpLgg4KS14KS/4KSt4KS+4KSXX+CkleClg+Ckt+CkvyDgpLXgpL/gpKrgpKPgpKgg4KSP4KS14KSCIOCkteCkv+CkpuClh+CktiDgpLXgpY3igI3gpK/gpL7gpKrgpL7gpLAg4KS14KS/4KSt4KS+4KSXHOCkleClg+Ckt+CkvyDgpLXgpL/gpK3gpL7gpJdS4KSV4KWD4KS34KS/IOCktuCkv+CkleCljeCkt+CkviDgpI/gpLXgpIIg4KSF4KSo4KWB4KS44KSC4KSn4KS+4KSoIOCkteCkv+CkreCkvuCklyXgpJXgpL7gpLDgpY3gpK7gpL/gpJUg4KS14KS/4KSt4KS+4KSXTuCkleCkvuCksOCljeCkr+CkleCljeCksOCkriDgpJXgpL7gpLDgpY3gpK/gpL7gpKjgpY3gpLXgpK/gpKgg4KS14KS/4KSt4KS+4KSXIFbgpJXgpL7gpLDgpL7gpJfgpL7gpLAg4KSq4KWN4KSw4KS24KS+4KS44KSoIOCkj+CkteCkgiDgpLjgpYHgpKfgpL7gpLAg4KS14KS/4KSt4KS+4KSXIBngpJbgpYfgpLIg4KS14KS/4KSt4KS+4KSXTOCkluCkvuCkpuCljeCkryDgpI/gpLXgpIIg4KSU4KS34KSn4KS/IOCkquCljeCksOCktuCkvuCkuOCkqCDgpLXgpL/gpK3gpL7gpJc24KSW4KS+4KSm4KWN4KSvIOCkj+CkteCkruCljSDgpLDgpLjgpKYg4KS14KS/4KSt4KS+4KSXSeCkluCkvuCkpuClgCDgpI/gpLXgpIIg4KSX4KWN4KSw4KS+4KSu4KWL4KSm4KWN4KSv4KWL4KSXIOCkteCkv+CkreCkvuCklyA14KSX4KWN4KSw4KS+4KSu4KWN4KSvIOCkteCkv+CkleCkvuCkuCDgpLXgpL/gpK3gpL7gpJdH4KSX4KWN4KSw4KS+4KSu4KWA4KSjIOCkheCkreCkv+Ckr+CkqOCljeKAjeCkpOCljeCksOCkoyDgpLXgpL/gpK3gpL7gpJca4KSX4KWD4KS5IOCkteCkv+CkreCkvuCklyAc4KSX4KWL4KSq4KSoIOCkteCkv+CkreCkvuCkl1HgpJrgpL/gpJXgpL/gpKTgpY3igI3gpLjgpL4g4KSP4KS14KSCIOCkuOCljeKAjeCkteCkvuCkuOCljeKAjeCkpSDgpLXgpL/gpK3gpL7gpJdW4KSa4KS/4KSV4KS/4KSk4KWN4oCN4KS44KS+IOCktuCkv+CkleCljeCkt+CkviDgpI/gpLXgpIIg4KSG4KSv4KWB4KS3IOCkteCkv+CkreCkvuCklyBc4KSa4KWA4KSo4KWAIOCkieCkpuCljeCkr+Cli+CklyDgpI/gpLXgpIIg4KSX4KSo4KWN4oCN4KSo4KS+IOCkteCkv+CkleCkvuCkuCDgpLXgpL/gpK3gpL7gpJcv4KSm4KWB4KSX4KWN4KSnIOCkteCkv+CkleCkvuCkuCDgpLXgpL/gpK3gpL7gpJcq4KSn4KSw4KWN4KSu4KS+4KSw4KWN4KSlIOCkleCkvuCksOCljeCkryAgKeCkqOCkl+CksCDgpLXgpL/gpJXgpL7gpLgg4KS14KS/4KSt4KS+4KSXZeCkqOCkl+CksOClgOCkryDgpLDgpYvgpJzgpJfgpL7gpLAg4KSP4KS14KSCIOCkl+CksOClgOCkrOClgCDgpIngpKjgpY3igI3gpK7gpYLgpLLgpKgg4KS14KS/4KSt4KS+4KSXH+CkqOCljeCkr+CkvuCkryDgpLXgpL/gpK3gpL7gpJc54KSo4KS+4KSX4KSw4KS/4KSVIOCkieCkoeCljeCkoeCkvOCkr+CkqCDgpLXgpL/gpK3gpL7gpJcgOeCkqOCkvuCkl+CksOCkv+CklSDgpLjgpYHgpLDgpJXgpY3gpLfgpL4g4KS14KS/4KSt4KS+4KSXIDzgpKjgpL/gpJzgpYAg4KSq4KWC4KSC4KSc4KWAIOCkqOCkv+CkteClh+CktiDgpLXgpL/gpK3gpL7gpJcp4KSo4KS/4KSv4KWB4KSV4KWN4KSk4KS/IOCkteCkv+CkreCkvuCklyAj4KSo4KS/4KSv4KWL4KSc4KSoIOCkteCkv+CkreCkvuCklyAp4KSo4KS/4KSw4KWN4KS14KS+4KSa4KSoIOCkteCkv+CkreCkvuCklyAu4KSq4KSC4KSa4KS+4KSv4KSk4KWA4KSw4KS+4KScIOCkteCkv+CkreCkvuCklzngpKrgpLDgpKTgpYAg4KSt4KWC4KSu4KS/IOCkteCkv+CkleCkvuCkuCDgpLXgpL/gpK3gpL7gpJcj4KSq4KSw4KWN4KSv4KSf4KSoIOCkteCkv+CkreCkvuCklyAo4KSq4KSw4KWN4KSv4KS+4KS14KSw4KSjIOCkteCkv+CkreCkvuCklzzgpKrgpY3gpLDgpLbgpL7gpLjgpKjgpL/gpJUg4KS44KWB4KSn4KS+4KSwIOCkteCkv+CkreCkvuCklyA/4KSq4KWN4KSw4KS+4KS14KS/4KSn4KS/4KSVIOCktuCkv+CkleCljeCkt+CkviDgpLXgpL/gpK3gpL7gpJcgIuCkquCksOCkv+CkteCkueCkqCDgpLXgpL/gpK3gpL7gpJcs4KSq4KWN4KSw4KWL4KSf4KWL4KSV4KS+4KSyIOCkteCkv+CkreCkvuCklyAf4KSq4KS24KWB4KSn4KSoIOCkteCkv+CkreCkvuCkl0bgpKrgpL/gpJvgpKHgpLzgpL4g4KS14KSw4KWN4KSXIOCkleCksuCljeKAjeCkr+CkvuCkoyDgpLXgpL/gpK3gpL7gpJcgI+CkrOCliOCkleCkv+CkguCklyDgpLXgpL/gpK3gpL7gpJcgReCkreClguCkpOCkpOCljeKAjeCktSDgpI/gpLXgpIIg4KSW4KSo4KS/4KSV4KSw4KWN4KSuIOCkteCkv+CkreCkvuCklx3gpK3gpL7gpLfgpL4g4KS14KS/4KSt4KS+4KSXIGrgpK7gpYHgpJbgpY3igI3gpK/gpK7gpILgpKTgpY3gpLDgpYAg4KSV4KS+4KSw4KWN4KSv4KS+4KSy4KSvIOCksuCli+CklSDgpLbgpL/gpJXgpL7gpK/gpKQg4KS14KS/4KSt4KS+4KSXKOCkruCkpOCljeKAjeCkuOCljeKAjeCkryDgpLXgpL/gpK3gpL7gpJdD4KSu4KS54KS/4KSy4KS+IOCkj+CkteCkgiDgpKzgpL7gpLIg4KS14KS/4KSV4KS+4KS4IOCkteCkv+CkreCkvuCkly/gpK/gpYHgpLXgpL4g4KSV4KSy4KWN4KSv4KS+4KSjIOCkteCkv+CkreCkvuCklxzgpLDgpYfgpLbgpK4g4KS14KS/4KSt4KS+4KSXOeCksOCkvuCknOCkqOCliOCkpOCkv+CklSDgpKrgpYfgpILgpLbgpKgg4KS14KS/4KSt4KS+4KSXIDzgpLDgpL7gpJzgpY3gpK8g4KSv4KWL4KSc4KSo4KS+IOCkhuCkr+Cli+CklyDgpLXgpL/gpK3gpL7gpJco4KSw4KS+4KSc4KWN4KSvIOCkuOCkruCljeCkquCkpOCljeCkpOCkvyXgpLDgpL7gpJzgpLjgpY3igI3gpLUg4KS14KS/4KSt4KS+4KSXQeCksOCkvuCkt+CljeKAjeCkn+CljeCksOClgOCkryDgpI/gpJXgpYDgpJXgpLDgpKMg4KS14KS/4KSt4KS+4KSXLOCksuCkmOClgSDgpLjgpL/gpILgpJrgpL7gpIgg4KS14KS/4KSt4KS+4KSXMOCksuCli+CklSDgpKjgpL/gpLDgpY3gpK7gpL7gpKMg4KS14KS/4KSt4KS+4KSXID3gpLLgpYvgpJUg4KS44KWH4KS14KS+IOCkquCljeCksOCkrOCkguCkp+CkqCDgpLXgpL/gpK3gpL7gpJcgFuCkteCkqCDgpLXgpL/gpK3gpL7gpJdo4KS14KWN4oCN4KSv4KS14KS44KS+4KSv4KS/4KSVIOCktuCkv+CkleCljeCkt+CkviDgpI/gpLXgpIIg4KSV4KWM4KS24KSyIOCkteCkv+CkleCkvuCkuCDgpLXgpL/gpK3gpL7gpJc34KS14KS44KWN4oCN4KSk4KWN4KSw4KWL4KSm4KWN4KSv4KWL4KSXIOCkteCkv+CkreCkvuCklz/gpLXgpL7gpLngpK8g4KS44KS+4KS54KS+4KSv4KSk4KS/4KSVIOCkquCksOCkv+Ckr+Cli+CknOCkqOCkviA44KS14KS/4KSV4KSy4KS+4KSC4KSXIOCkleCksuCljeCkr+CkvuCkoyDgpLXgpL/gpK3gpL7gpJdV4KS14KS/4KSc4KWN4KSe4KS+4KSoIOCkj+CkteCkgiDgpKrgpY3gpLDgpYvgpKbgpY3gpK/gpYvgpJfgpL/gpJXgpYAg4KS14KS/4KSt4KS+4KSXICLgpLXgpL/gpKTgpY3igI3gpKQg4KS14KS/4KSt4KS+4KSXIuCkteCkv+Ckp+CkvuCkr+ClgCDgpLXgpL/gpK3gpL7gpJcc4KS24KWN4KSw4KSuIOCkteCkv+CkreCkvuCklyLgpLbgpL/gpJXgpY3gpLfgpL4g4KS14KS/4KSt4KS+4KSXWeCkuOClguCkleCljeCkt+CljeCkrizgpLLgpJjgpYEg4KSP4KS14KSCIOCkruCkp+CljeCkr+CkriDgpIngpKbgpY3gpK/gpK4g4KS14KS/4KSt4KS+4KSXTuCkuOClguCkmuCkqOCkviDgpI/gpLXgpIIg4KSq4KWN4KSw4KWM4KSm4KWN4KSv4KWL4KSX4KS/4KSV4KWAIOCkteCkv+CkreCkvuCklyDgpLjgpYLgpJrgpKjgpL4g4KS14KS/4KSt4KS+4KSXIDzgpLjgpJrgpL/gpLXgpL7gpLLgpK8g4KSq4KWN4KSw4KS24KS+4KS44KSoIOCkteCkv+CkreCkvuCklyBR4KS44KWN4KSf4KS+4KSu4KWN4KSqIOCkj+CkteCkgiDgpLDgpJzgpL/gpLjgpY3gpJ/gpY3gpLDgpYfgpLbgpKgg4KS14KS/4KSt4KS+4KSXJeCkuOCkpOCksOCljeCkleCkpOCkviDgpLXgpL/gpK3gpL7gpJc14KS44KWI4KSo4KS/4KSVIOCkleCksuCljeKAjeCkr+CkvuCkoyDgpLXgpL/gpK3gpL7gpJdI4KS44KSu4KSX4KWN4KSwIOCkl+CljeCksOCkvuCkruCljeKAjeCkryDgpLXgpL/gpJXgpL7gpLgg4KS14KS/4KSt4KS+4KSXIuCkuOCkruCkqOCljeCkteCkryDgpLXgpL/gpK3gpL7gpJcv4KS44KSu4KS+4KScIOCkleCksuCljeCkr+CkvuCkoyDgpLXgpL/gpK3gpL7gpJeGAeCkuOCljeKAjeCkteCkpOCkqOCljeKAjeCkpOCljeCksOCkpOCkviDgpLjgpILgpJfgpY3gpLDgpL7gpK4g4KS44KWH4KSo4KS+4KSo4KWAIOCkleCksuCljeKAjeCkr+CkvuCkoyDgpKrgpLDgpL/gpLfgpKYg4KS14KS/4KSt4KS+4KSXaOCkuOCkguCkuOCljeKAjeCkpeCkvuCkl+CkpCDgpLXgpL/gpKTgpY3igI3gpKQg4KSV4KSwIOCkj+CkteCkgiDgpKjgpL/gpKzgpKjgpY3igI3gpKfgpKgg4KS14KS/4KSt4KS+4KSXIuCkuOCkguCkuOCkpuClgOCkryDgpLXgpL/gpK3gpL7gpJcp4KS44KS54KSV4KS+4KSw4KS/4KSk4KS+ICDgpLXgpL/gpK3gpL7gpJc/4KS44KS+4KSu4KS+4KSo4KWN4oCN4KSvIOCkquCljeCksOCktuCkvuCkuOCkqCDgpLXgpL/gpK3gpL7gpJcgPOCkuOCkvuCksOCljeCkteCknOCkqOCkv+CklSDgpIngpKbgpY3gpK/gpK4g4KS14KS/4KSt4KS+4KSXIC/gpLjgpL7gpILgpLjgpY3igI3gpJXgpYPgpKTgpL8g4KS14KS/4KSt4KS+4KSXIEbgpLjgpL/gpILgpJrgpL7gpIgg4KSP4KS14KSCIOCknOCksiDgpLjgpILgpLjgpL7gpKfgpKgg4KS14KS/4KSt4KS+4KSXLOCkueCli+CkruCkl+CkvuCkoeCksOCljeCkuCDgpLXgpL/gpK3gpL7gpJcgFWABMAMxNzYCNjQDMTgxAjE5AzE4NgMxNjcDMjAzAjc0AzIxMwExAzIxOAMxODIDMTAyAjM3AjM5AzE2MwMxOTECMTUDMjA4AzIwMgIzOAMxNjgCNDACNDcDMTY1AzIxNQMyMDECMjUBOQMxNDIDMTkzAzE3MAMyMTECNDYBNgI5NwMyMTIDMTc0AjU0AzE5MgI4MAMxNDcBNwMxNTcCNjECMTICMjMDMTgzAjQxAjIwAzE5OQMyMTQCNjMDMjE3AjQ0AzExNgMxMTEDMTQ1AzE5OAEyAzE3MQMxNzUDMjA3AzExMAIzNAMyMDQCMzUDMTgwAzE0NgMxMjADMTE4AzEwMAMxNjIDMTg5AjIxAzE3MwMxNjYDMTg4Ajc5AjM2Ajk0AzE1MAMyMDkDMjEwAzE4NAMxMDcDMjA2AzE5NgMxODUCMTYCNDgDMTYxAjY1AzE4NwIxNxQrA2BnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2cWAWZkAgUPEGRkFgBkAiMPDxYCHghJbWFnZVVybAVMSnBlZ0ltYWdlLmFzcHg/Z3VpZD1OV1UyWmpNNFl6WXRNVGs1WWkwMFlUUTBMV0ZqWVRrdE5UazNNREJsTjJRME4yVXlJemt4TlRJPWRkAgYPZBYCZg9kFgRmDw8WAh8GBUHgpKjgpLXgpYDgpKjgpKTgpK4g4KSF4KSq4KSy4KWL4KSh4KWH4KShIOCktuCkvuCkuOCkqOCkvuCkpuClh+CktmRkAgEPDxYCHwYFXuCkteCkv+CkreCkvuCkly/gpLbgpL7gpLjgpKjgpL7gpKbgpYfgpLYg4KS44KSC4KSW4KWN4KSv4KS+L+CkheCkquCksuCli+CkoSDgpKbgpL/gpKjgpL7gpILgpJVkZAIHD2QWAmYPZBYCAgEPZBYCZg9kFgICAQ9kFgRmD2QWAgIBD2QWBAIBDxYCHgdWaXNpYmxlaGQCBQ8QZGQWAWZkAgIPZBYCZg9kFgQCAQ8UKwACZGRkAgUPFCsAAmQQFgAWABYAZBgCBQ1JdGVtRGF0YVBhZ2VyDxQrAARkZAIZZmQFCUxpc3RWaWV3MQ88KwAOAgxmDQIZZOWmEfnwRGf1dXFVe5YbcOIo28K4jbDOBPa6bKNn/pua" />

</div>



<script type="text/javascript">

//<![CDATA[

var theForm = document.forms['form1'];

if (!theForm) {

    theForm = document.form1;

}

function __doPostBack(eventTarget, eventArgument) {

    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {

        theForm.__EVENTTARGET.value = eventTarget;

        theForm.__EVENTARGUMENT.value = eventArgument;

        theForm.submit();

    }

}

//]]>

</script>





<script src="/WebResource.axd?d=165Jf6pO_gJ131_87A3A_dyikzKA6qw4_TRU_twd98O6rDNXfEaRer9Ko3aKtZ8isEr_I376Nf0GOCJseu7x0PDcPD4G6JvyTnwECyHQnY81&amp;t=635828947644985307" type="text/javascript"></script>





<script src="/ScriptResource.axd?d=4-OxIkSpBit-gj4Pv2yjz3pPXMb7_13IXspIUKjL0H_-QGG-zeqYooxDE5PkGiHSeHpSh785KOEpNZIeueOsinJdOvZRwLiH607afuwXhF7BiAF5yEMbB5CrFxTBGQs0ljbBz28xa0_8XBlHR96T88FZFd7fNsK0FAOarr-zaIE1&amp;t=fffffffff9bf6f51" type="text/javascript"></script>

<script src="/ScriptResource.axd?d=aLEo2EEmKGtu37BQa5_H0prvkAfAGY1ucKWq8aBbx81OsQ5WGBVm6RThn8aGHLRVtukdD9kzf5NMePewjyeNtld8C_7cYBgoh67ewFjwENBWfS3F6lfIGdIoXHUPVMF57pZXZT0KVwG38Dgd3CFXzNarod-F_Jx0FdyUVIFwRB7LM9lbd4eXAloCnliZA1w00&amp;t=ffffffffaf0b2df4" type="text/javascript"></script>

<script type="text/javascript">

//<![CDATA[

if (typeof(Sys) === 'undefined') throw new Error('ASP.NET Ajax client-side framework failed to load.');

//]]>

</script>



<script src="/ScriptResource.axd?d=kFQ49eC0_Fv_IklG8r5kGBTqy5uLDMYTpSnRexnjNrAzwsls08Qt1OAD4Qh09qLShALia24w2TWB7k-_oGZRqrBZ1lZbKCuyfeOCC6M155I33rkuM5qKWslUsneuADFIyQh2X8jLLrfYqDX8BfD_z0pSnJOGXwvpjlGcl0kM-l5ro5mNC2FC28kcLD7NlVeC0&amp;t=ffffffffaf0b2df4" type="text/javascript"></script>

<script src="/ScriptResource.axd?d=rqxQw4Ii7ae16281ogkLT1ecNZ3pWLL3A3sXfL-DYn2IQUqG9v0h5yQRb6-6wLXWJ3Ein8mco_Of3lenpmbh7lrde9wrvTO2wKS1u6JnHUXK6FN_6aFJyjXuEfr_BDRIPb3XBMMltC065gG3zir0g_nLzDAjnC1kDxoGcnsbSNYfnBugiCAysIlOm7WF5U3s0&amp;t=ffffffffaf0b2df4" type="text/javascript"></script>

<script src="/WebResource.axd?d=uLZxnx3ro9bvDO8gqDvDncHnYS18-XR5OKxFFEnHzugUtyjUxNWzAn0AAoMrifyEuwpDRgdWS5Vmbq5fHoVGbr5SIj3-843aDYeVG6jI-EU1&amp;t=635828947644985307" type="text/javascript"></script>

<script type="text/javascript">

//<![CDATA[

function WebForm_OnSubmit() {

if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;

return true;

}

//]]>

</script>



<div class="aspNetHidden">



	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />

</div>

    <div>

        

        <script type="text/javascript">

//<![CDATA[

Sys.WebForms.PageRequestManager._initialize('ScriptManager1', 'form1', ['tUpdatePanel3','UpdatePanel3','tUpdatePanel1','UpdatePanel1','tTimedPanel','TimedPanel','tUpdatePanel2','UpdatePanel2'], ['btnupload','btnupload','ddldept','ddldept','UpdateTimer','UpdateTimer'], [], 90, '');

//]]>

</script>



         <div>

        </div>

         <span id="UpdateTimer" style="visibility:hidden;display:none;"></span>

      <div id="UpdateProgress1" style="display:none;">

	

                <div id="progressBackgroundFilter">

                </div>

                <div id="processMessage" align="center" style="position: absolute; padding: 5px;

                    top: 450px; left: 311px;">

                    <img alt="Loading" src="GO/img4.gif" width="30%" height="40%" /><br />

                    <br />

                    कृपया प्रतीक्षा करे.....

                </div>

            

</div> 

      

        <table style="width: 100%;" cellspacing="0" cellpadding="0" border="0">

            <tr>

                <td class="hld" align="center" valign="top" width="100%">

                   <div class="a">

                            

 





<table style="top:0px;background-color:darkred"  cellpadding="0" 

    cellspacing="0" width="100%">

            <tr>

                <td   align="center"  valign="top" width="85%">

                    <img id="header_Image2" src="GO/UC/images/header.gif" /> 

                     

                    

                </td>

                <td style="width:15%" align="center">

                  <div id="google_translate_element"  style="height:75px; ">

                    <script  language="javascript" type="text/javascript" defer="defer">

                        function googleTranslateElementInit() {

                            new google.translate.TranslateElement({ pageLanguage: 'en', multilanguagePage: true }, 'google_translate_element');

                        }

                    </script>

                    <script language="javascript" type="text/javascript" defer="defer" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

                    </div>     

                </td>                

            </tr>

        </table>

   

     

                              

        <img alt="" src ="GO/images/line1.gif" 

                style ="width :100%; vertical-align: top; margin-top: -4px;" />

                              </div> 

                </td>

            </tr>





            <tr>

                <td align="left" >

                    <div class="a">

                     <div id="UpdatePanel3">

	

                        <table width="100%">

                            <tr>

                                <td align="left"  width="50%">

                                    <span id="lblhit" class="hld_new">No. of Searches & GO's downloaded:-6943392</span></td>

                                <td align="right"  width="50%">

                                  

                                 <a id="HyperLink3" class="hld_report" href="impdownld.htm" target="_blank">Imp DownLoads</a>&nbsp;

                                                                     

                                  

                                    </td>

                                </tr></table>

                                

</div>

                                 

                    </div>

                </td>

            </tr>

            

        </table>

                                

                       

                    

           <table  style="width: 100%;" cellspacing="0" cellpadding="0" border="0">      

      

                        

                    

                    <tr style="width:100%" >

                        <td align="center"   width="100%" >

                            <table  width="100%"  align="center">

                                <tr  style="width:100%"  >

                                    <td align="center" width="100%" >

                                        <table  width= "100%"  style="font-size:11px;" align="center"   >



                                            <tr style="width:100%;" class="a"  >

                                             

                                                <td    class="abc a" align="center"  colspan="1"   width ="50%" 

                                                    valign="top"   >

                                               

                                                 <table  cellpadding="0" cellspacing="0" class="FontStyle" width="100%" 

                                                        style=" margin-top:10px; margin-bottom:10px; background-color: White;position:relative; top: 0px; left: 0px;"    >

                                                        

                                                        <tr style="width:100%" >

                                                            <td colspan="3"  width="100%" valign="top" height="375px">

                                                   

                                                      <div id="UpdatePanel1">

	

                                                       <table  width="100%;"    cellpadding="0" cellspacing="0" style="background-color:White; " >

                                        

                                       <tr style="width:100%;height:10%">

                                       <td colspan="3" align="center" style="font-weight:bold;font-family:Verdana;background-color:#017931;width:100%;" valign="top" >

                                       <span id="lbl22" style="font-size:15px; color:white">शासनादेश खोजें</span>

                                       </td>

                                       </tr>



                                        <tr   style="width:100%;height:23px"   >

                    <td align="center"   colspan="3"    style="background-color:#8B0707;">

                      <marquee behavior="alternate"  ONMOUSEOVER="this.stop()"  

            ONMOUSEOUT="this.start()" scrolldelay="300"> <span style="color:White;font-size:11px">कृपया ध्यान दे- क्रं सं० 2,3,4,5,6 का चयन वैकल्पिक हैं!</span></marquee>   </td>

                </tr>

                

                   

                                      



                                        <tr  style="width:100%;height:35px;"    >

                                         <td  class ="border_ltr_1"  width="3%" >

                                               1.</td>

                                               <td class="border_ltr_2"   width="50%"  >

                                                विभाग <span style="color:Red">*</span> </td>

                                            <td class="border_ltr_3"  width="42%" valign="middle" >

                                                &nbsp;<select name="ddldept" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ddldept\&#39;,\&#39;\&#39;)&#39;, 0)" id="ddldept" class="hh" onkeyup="SetButtonStatus(this, &#39;btnupload&#39;)" style="width:90%; border:thin solid #8B0707;">

		<option selected="selected" value="0">समस्त विभाग</option>

		<option value="176">अतिरिक्‍त ऊर्जा श्रोत विभाग </option>

		<option value="64">अल्‍पसंख्‍यक कल्‍याण विभाग</option>

		<option value="181">अवस्थापना विकास विभाग</option>

		<option value="19">आबकारी विभाग </option>

		<option value="186">आवास विभाग</option>

		<option value="167">उच्‍च शिक्षा विभाग </option>

		<option value="203">उत्‍तर प्रदेश पुनर्गठन समन्‍वय विभाग</option>

		<option value="74">उद्यान विभाग</option>

		<option value="213">उपभोक्‍ता संरक्षण एवं बाट माप विभाग</option>

		<option value="1">ऊर्जा विभाग</option>

		<option value="218">एन.आर.आई  विभाग</option>

		<option value="182">औद्योगिक विकास विभाग</option>

		<option value="102">कृषि विपणन एवं विदेश व्‍यापार विभाग</option>

		<option value="37">कृषि विभाग</option>

		<option value="39">कृषि शिक्षा एवं अनुसंधान विभाग</option>

		<option value="163">कार्मिक विभाग</option>

		<option value="191">कार्यक्रम कार्यान्वयन विभाग </option>

		<option value="15">कारागार प्रशासन एवं सुधार विभाग </option>

		<option value="208">खेल विभाग</option>

		<option value="202">खाद्य एवं औषधि प्रशासन विभाग</option>

		<option value="38">खाद्य एवम् रसद विभाग</option>

		<option value="168">खादी एवं ग्रामोद्योग विभाग </option>

		<option value="40">ग्राम्य विकास विभाग</option>

		<option value="47">ग्रामीण अभियन्‍त्रण विभाग</option>

		<option value="165">गृह विभाग </option>

		<option value="215">गोपन विभाग</option>

		<option value="201">चिकित्‍सा एवं स्‍वास्‍थ विभाग</option>

		<option value="25">चिकित्‍सा शिक्षा एवं आयुष विभाग </option>

		<option value="9">चीनी उद्योग एवं गन्‍ना विकास विभाग</option>

		<option value="142">दुग्ध विकास विभाग</option>

		<option value="193">धर्मार्थ कार्य  </option>

		<option value="170">नगर विकास विभाग</option>

		<option value="211">नगरीय रोजगार एवं गरीबी उन्‍मूलन विभाग</option>

		<option value="46">न्याय विभाग</option>

		<option value="6">नागरिक उड्ड़यन विभाग </option>

		<option value="97">नागरिक सुरक्षा विभाग </option>

		<option value="212">निजी पूंजी निवेश विभाग</option>

		<option value="174">नियुक्ति विभाग </option>

		<option value="54">नियोजन विभाग </option>

		<option value="192">निर्वाचन विभाग </option>

		<option value="80">पंचायतीराज विभाग</option>

		<option value="147">परती भूमि विकास विभाग</option>

		<option value="7">पर्यटन विभाग </option>

		<option value="157">पर्यावरण विभाग</option>

		<option value="61">प्रशासनिक सुधार विभाग </option>

		<option value="12">प्राविधिक शिक्षा विभाग </option>

		<option value="23">परिवहन विभाग</option>

		<option value="183">प्रोटोकाल विभाग </option>

		<option value="41">पशुधन विभाग</option>

		<option value="20">पिछड़ा वर्ग कल्‍याण विभाग </option>

		<option value="199">बैकिंग विभाग </option>

		<option value="214">भूतत्‍व एवं खनिकर्म विभाग</option>

		<option value="63">भाषा विभाग </option>

		<option value="217">मुख्‍यमंत्री कार्यालय लोक शिकायत विभाग</option>

		<option value="44">मत्‍स्‍य विभाग</option>

		<option value="116">महिला एवं बाल विकास विभाग</option>

		<option value="111">युवा कल्याण विभाग</option>

		<option value="145">रेशम विभाग</option>

		<option value="198">राजनैतिक पेंशन विभाग </option>

		<option value="2">राज्य योजना आयोग विभाग</option>

		<option value="171">राज्य सम्पत्ति</option>

		<option value="175">राजस्‍व विभाग</option>

		<option value="207">राष्‍ट्रीय एकीकरण विभाग</option>

		<option value="110">लघु सिंचाई विभाग</option>

		<option value="34">लोक निर्माण विभाग </option>

		<option value="204">लोक सेवा प्रबंधन विभाग </option>

		<option value="35">वन विभाग</option>

		<option value="180">व्‍यवसायिक शिक्षा एवं कौशल विकास विभाग</option>

		<option value="146">वस्‍त्रोद्योग विभाग</option>

		<option value="120">वाहय साहायतिक परियोजना </option>

		<option value="118">विकलांग कल्याण विभाग</option>

		<option value="100">विज्ञान एवं प्रोद्योगिकी विभाग </option>

		<option value="162">वित्‍त विभाग</option>

		<option value="189">विधायी विभाग</option>

		<option value="21">श्रम विभाग</option>

		<option value="173">शिक्षा विभाग</option>

		<option value="166">सूक्ष्म,लघु एवं मध्यम उद्यम विभाग</option>

		<option value="188">सूचना एवं प्रौद्योगिकी विभाग</option>

		<option value="79">सूचना विभाग </option>

		<option value="36">सचिवालय प्रशासन विभाग </option>

		<option value="94">स्टाम्प एवं रजिस्ट्रेशन विभाग</option>

		<option value="150">सतर्कता विभाग</option>

		<option value="209">सैनिक कल्‍याण विभाग</option>

		<option value="210">समग्र ग्राम्‍य विकास विभाग</option>

		<option value="184">समन्वय विभाग</option>

		<option value="107">समाज कल्याण विभाग</option>

		<option value="206">स्‍वतन्‍त्रता संग्राम सेनानी कल्‍याण परिषद विभाग</option>

		<option value="196">संस्‍थागत वित्‍त कर एवं निबन्‍धन विभाग</option>

		<option value="185">संसदीय विभाग</option>

		<option value="16">सहकारिता  विभाग</option>

		<option value="48">सामान्‍य प्रशासन विभाग </option>

		<option value="161">सार्वजनिक उद्यम विभाग </option>

		<option value="65">सांस्‍कृति विभाग </option>

		<option value="187">सिंचाई एवं जल संसाधन विभाग</option>

		<option value="17">होमगाडर्स विभाग </option>



	</select>

                                            </td></tr>

                                            

                                          

                                            <tr  style="width:100%;height:35px;"  >

                                             <td  class ="border_ltr_1" width="3%"  >

                                                 2.</td>

                                            <td class="border_ltr_2"  width="50%"  >

                                                अनुभाग</td>

                                                <td class="border_ltr_3" width="42%"  >

                                                   &nbsp;<select name="ddlsection" id="ddlsection" class="hh" onkeyup="SetButtonStatus(this, &#39;btnupload&#39;)" style="width:90%; border:thin solid #8B0707;">



	</select>

                                                </td>

                                        </tr>

                                            

                                            <tr  style="width:100%;height:35px;"   >

                                              <td  class ="border_ltr_1"  width="3%" >

                                                  3.</td>

                                            <td  class="border_ltr_2"   width="50%"  >

                                                श्रेणी</td>

                                            <td class="border_ltr_3" width="42%" valign="middle" >

                                               &nbsp;<select name="ddlcat" id="ddlcat" class="hh" style="width:90%; border:thin solid #8B0707;">



	</select>

                                            </td>

                                           

                                        </tr>

                                        

                                        <tr style="width:100%;height:35px;" >

                                             <td  class ="border_ltr_1" width="3%" >

                                                 4.</td>

                                            <td class="border_ltr_2" nowrap="nowrap"  width="50%" >

                                              शासनादेश तिथि<br/><span style="color:Red;font-size:11px; font-weight: normal;">(वैकल्पिक) </span>

                                               <span id="RegularExpressionValidator1" style="visibility:hidden;">*</span>



                                                        <span id="RegularExpressionValidator2" style="visibility:hidden;">*</span>

                                              </td>

                                            <td class="border_ltr_3" width="40%" valign="middle" >

                                             &nbsp;<input name="txtGOdate" type="text" maxlength="10" id="txtGOdate" class="hh" onblur="validatedate(&#39;txtGOdate&#39;);" style="width:21%; border:thin solid #8B0707;resize:none;" />

                                               <input type="submit" name="Button1" value="..." onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="Button1" class="hh" style="width:15px;" />

                                                से

                                                <input name="txtGOdate0" type="text" maxlength="10" id="txtGOdate0" class="hh" onblur="validatedate(&#39;txtGOdate0&#39;);" style="width:21%; border:thin solid #8B0707;resize:none;" />

                                                <input type="submit" name="Button2" value="..." onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;Button2&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="Button2" class="hh" style="width:15px;" />

                                              

                                                तक <span class="style3">(dd/mm/yyyy)</span>

                                               



                                                     

                                             

                                             

                                               </td>

                                            </tr>

                                            

                                       

                                        <tr  style="width:100%;height:35px;" >

                                            <td  class ="border_ltr_1" width="3%" >

                                                5.</td>

                                            <td class="border_ltr_2"  width="50%"  >

                                                शासनादेश संख्या <br/><span style="color:Red;font-size:11px;font-weight: normal;">(वैकल्पिक) </span> </td>

                                            <td class="border_ltr_3" width="42%" valign="middle" >

                                               

                                                &nbsp;<input name="txtGOid" type="text" maxlength="100" id="txtGOid" class="hh" onkeyup="SetButtonStatus(this, &#39;btnupload&#39;)" style="width:90%; border:thin solid #8B0707;resize:none;" />

                                               

                                                <span id="RegularExpressionValidator3" style="visibility:hidden;">*</span>

                                               

                                            </td>

                                        </tr>

                                       

                                       

                  <tr  style="width:100%;height:35px;" valign="top"  >

                                            <td  class ="border_ltr_1" width="3%" valign="middle" >

                                                6.</td>

                                            <td class="border_ltr_2"  width="50%" valign="middle"  >

                                             खोज शब्द समूह <br/> <span style="color:Red;font-size:11px;font-weight: normal;">(वैकल्पिक) </span> </td>

                                            <td class="border_ltr_3" width="40%" valign="middle">

                                               

                                               &nbsp;<input name="txtSubj" type="text" maxlength="100" id="txtSubj" class="hh" style="width:90%; border:thin solid #8B0707;" />                                                   

                                                                                            

                                                                                              



                                            </td>

                                        </tr>

                                                           <tr style="width:100%;height:35px;" valign="top">

                                                               <td style="border-right-color:#666666; border-left-color: #666666;border-left-width:1px;border-right-width:1px;border-left-style:solid;border-right-style:solid; " valign="middle" width="3%">

                                                                   &nbsp;</td>

                                                               <td  style="border-right-color:#666666; border-left-color: #666666;border-left-width:1px;border-right-width:1px;border-left-style:solid;border-right-style:solid; " valign="middle"  width="22%">

                                                                   &nbsp;</td>

                                                               <td   style="border-right-color:#666666; border-left-color: #666666;border-left-width:1px;border-right-width:1px;border-left-style:solid;border-right-style:solid;  " align="left"  valign="bottom"   width="40%"> <span class="style3" style="width:90%; margin-left:10px;margin-right:10px;" >&nbsp;(हिन्दी एवम अंग्रेजी दोनो मे टाइप किया जा सकता हैं|यदि अंग्रेजी में टाइप <br/>&nbsp;&nbsp; करते हैं तो,स्पेस देने के  पश्चात् हिंदी में लिप्यंतरण स्वतः हो जाएगा)</span>

                                                                   &nbsp;</td>

                                                           </tr>

                                        

                                                         

                                                         

                                                         

                                                            <tr  style="width:100%;height:30px;"  valign="top">

                                                                <td     style="width: 100%;" colspan="3">

                                                                    <table cellpadding="0" cellspacing="0" style="width: 100%">

                                                                        <tr>

                                                                         

                                                                            <td align="left" class="border_ltb" valign="middle"  width="50%" >

                                                                                 <span id="Label3" style="color:Maroon;font-family:Verdana;font-size:12px;font-weight:normal;">कृपया दिए गए अंको को बॉक्स में अंकित करें।</span>

                                                                               

                                                                            </td>

                                                                            <td align="left" class="border_all_g" valign="top" width="50%">



                                                                            <table width="100%">

                                                                            <tr><td width="30%">

                                                                                <input name="CodeNumberTextBox" type="text" maxlength="4" id="CodeNumberTextBox" onkeyup="SetButtonStatus(this, &#39;btnupload&#39;)" style="width:40px; border:thin solid #8B0707;resize:none;" />

                                                                                    </td>

                                                                                    <td width="30%" valign="top">

                                                                                <img id="Image1" src="JpegImage.aspx?guid=NWU2ZjM4YzYtMTk5Yi00YTQ0LWFjYTktNTk3MDBlN2Q0N2UyIzkxNTI=" style="height:30px;width:80px;" />

                                                                                </td>

                                                                            <td width="40%" valign="middle">&nbsp;<input type="submit" name="btnRefresh" value="रिफ्रेश करें" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;btnRefresh&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="btnRefresh" style="font-family:Rod;" /></td>

                                                                            

                                                                            </tr>

                                                                            </table>

                                                                                

                                                                                

                                                                                

                                                                            </td>

                                                                            

                                                                        </tr>

                                                          

                                                                    </table>

                                                                </td>

                                                            </tr>

                                                            

                                                           

                                             

                                                

                                                 <tr  style="width:100%;height:5%"" >

                                                                <td align="center" class="hld1 border_ltr" colspan="3" width="100%" 

                                                                    valign="middle" >

                                                                 <input type="hidden" name="HiddenField1" id="HiddenField1" value="9152" />

                                                                    <input type="submit" name="btnupload" value="खोजें " id="btnupload" disabled="disabled" class="aspNetDisabled" style="margin-bottom: 0px" />  &nbsp; &nbsp; &nbsp;  <input id="Button3"  

                                        onclick="javascript: window.close();" type="button" value="बंद करें" />

                                                                   

                                                                   </td>

                                                            </tr>



                                                     

                                                        <tr>

                                                <td colspan="3">

                                                    <span id="Lbdept" style="color:Red;"></span>

                                                </td>

                                                 

                                            </tr>  

                                                        </table>

                                                       







              

</div>





         </td>

         </tr>

         </table>

         

                                                </td>

                 

                                                <td  class="abc a "   valign="top" colspan="1"   width ="50%"  >

                                            <table  cellpadding="0" cellspacing="0" class="FontStyle" width="100%" style=" margin-top:10px; margin-bottom:10px;background-color: #ffffff; position:relative;"   >

                                                        <tr style="height:55%" >

                                                            <td colspan="3"  width="100%">

                                                             <div id="TimedPanel">

	  

       

       

                                                                <table  width="100%" cellpadding="0" cellspacing="0" style="height:100%" >

                                                                    <tr  style="height:5%;background-color: #017931;" >

                                                                        <td colspan="3" align="center" style="font-weight:bold; color:white; font-family:Verdana; color:white;" valign="top"  >

                                                                            <span id="lblGO" style="font-size:15px;">नवीनतम अपलोडेड शासनादेश</span>



                                                                        </td>

                                                                    </tr>

                                                                    <tr  style="height:20">

                                                                        <td style="border: 1px solid black; background-color:#8B0707; color:white; width:3%;font-size:13px;"  align="center" >क्रसं</td>

                                                                        <td style="border: 1px solid black; background-color:#8B0707; color:white; width:47%;font-size:13px;" align="center"><span id="head">विभाग/शासनादेश संख्या/अपलोड दिनांक</span> </td>

                                                                        <td style="border: 1px solid black; background-color:#8B0707; color:white; width:50%;font-size:13px;" align="center" >विषय</td>

                                                                    </tr>

                                                            

                                                                 

                                                                    <tr  style="height:40%">

                                                                         

                                                                        <td colspan="3">

                                                                           

                                                                             <marquee   bgcolor=white    direction=up behavior="scroll" ONMOUSEOVER="this.stop()" height="135"

            ONMOUSEOUT="this.start()" scrolldelay=500  style="Width:100%;">

                                                                                 <table id="MARQ" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse; vertical-align:top;height:100%;">

                                                                              

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >1</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">लोक निर्माण विभाग </span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=Mjk1IzM0IzE0IzIwMTY="> 

                                

                                  

                               295/2016/946/23-14-2016-28आ0पू0वि0नि0/16  </a><br /><span >21/09/2016  7:53PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >वित्तीकय वर्ष 2016-17 में पूर्वान्च्ल विकास निधि (राज्यांाश) अनुदान संख्या्-56 में 	जनपद-जौनपुर के अन्तडर्गत 03 परियोजनाओं का निर्माण कार्य कराये जाने हेतु 	प्रशासकीय एवं वित्तीकय स्वीनक़ृति के संबंध में।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >2</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">लोक निर्माण विभाग </span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=Mjk0IzM0IzE0IzIwMTY="> 

                                

                                  

                               294/2016/999/तेईस-14-2016-05आ0जि0यो0(न0)/16     </a><br /><span >21/09/2016  7:39PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >वित्तीकय वर्ष 2016-17 में अनुदान संख्या्-58 के नक्स ल योजना के अन्त र्गत नये निर्माण के 05 कार्यों हेतु प्रशासकीय एवं वित्तीनय स्वी‍कृति के संबंध में।    <br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >3</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">लोक निर्माण विभाग </span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=MjkzIzM0IzE0IzIwMTY="> 

                                

                                  

                               293/2016/776/23-14-2016-100आ0पू0वि0नि0/15 </a><br /><span >21/09/2016  7:32PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >पूर्वान्चरल विकास निधि (राज्यांपश) अनुदान संख्यार-56 के अन्त र्गत जनपद-गोण्डाे की 01 	परियोजना के अवशेष कार्यों को पूर्ण करने हेतु वित्तीनय वर्ष 2016-17 में धनराशि का 	आवंटन।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >4</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">लोक निर्माण विभाग </span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=MjkyIzM0IzE0IzIwMTY="> 

                                

                                  

                               292/2016/780/23-14-2016-53आ0पू0वि0नि0/15  </a><br /><span >21/09/2016  7:27PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >वित्ती य वर्ष 2016-17 में पूर्वान्चवल विकास निधि (राज्यांाश) अनुदान संख्याि-56 में 	जनपद-बस्तीी की 01 परियोजना के अवशेष कार्य को पूर्ण करने हेतु धनराशि का 	आवंटन। <br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >5</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">लोक निर्माण विभाग </span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=MjkxIzM0IzE0IzIwMTY="> 

                                

                                  

                               291/2016/777/23-14-2016-103आ0पू0वि0नि0/14 </a><br /><span >21/09/2016  7:23PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >पूर्वान्चरल विकास निधि (राज्यां्श) अनुदान संख्यान-56 के अन्त र्गत जनपद-बलिया   	की 01 परियोजना के अवशेष कार्य को पूर्ण करने हेतु वित्तीखय वर्ष 2016-17 में 	धनराशि का आवंटन।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >6</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">राजस्‍व विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=NjUjMTc1IzEjMjAxNg=="> 

                                

                                  

                               65/2016/संख्या-529/एक-1-2016-5(55)/2012 </a><br /><span >21/09/2016  6:24PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >भारत सरकार को डेडीकेटेड फ्रेंट कारीडोर रेल परियोजना हेतु भूमि उपलब्ध कराना।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >7</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">नियोजन विभाग </span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=MzEwIzU0IzQjMjAxNg=="> 

                                

                                  

                               310/2016/1269/35-4-2016 </a><br /><span >21/09/2016  6:20PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >जनपद जालौन में वर्ष 2016-17 में त्‍वरित आर्थिक विकास योजना के अंतर्गत धनराशि की स्‍वीकृति ।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >8</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">नियोजन विभाग </span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=MzEyIzU0IzQjMjAxNg=="> 

                                

                                  

                               312/2016/1274/35-4-2016 </a><br /><span >21/09/2016  6:18PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >जनपद गाजीपुर में वर्ष 2016-17 में त्‍वरित आर्थिक विकास योजना के अंतर्गत धनराशि की स्‍वीकृति ।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >9</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">कृषि विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=MzMjMzcjMiMyMDE2"> 

                                

                                  

                               33/2016/2580 /12-2-2016 </a><br /><span >21/09/2016  5:41PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >प्रमाणित बीजों पर अनुदान दिये जाने की योजनान्तंगत तिलहनी फसलों के बीजों पर बुन्‍देलखण्‍ड क्षेत्र के जनपदों एवं जनपद सोनभद्र, फतेहपुर एवं मिर्जापुर के लिए विशेष प्रोत्सा‍हन हेतु कृषकों को उन्नोतशील प्रजातियों पर अनुमन्य अनुदान में संशोधन।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >10</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">नगर विकास विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=ODQjMTcwIzUjMjAxNg=="> 

                                

                                  

                               84/2016/1269/नौ-5-2016-357बजट/2014 </a><br /><span >21/09/2016  5:34PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >वित्‍तीय वर्ष 2016-17 में नगरीय सड़क सुधार योजनान्‍तर्गत 12 नगर पंचायतों को प्रथम किश्‍त की धनराशि की स्‍वीकृति।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >11</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">राजस्‍व विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=NjQjMTc1IzEjMjAxNg=="> 

                                

                                  

                               64/2016/संख्या -871/एक-1-2016-5(10)/2015 </a><br /><span >21/09/2016  5:09PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >मुद्रण एवं लेखन सामग्री के बीजक की धनराशि का भुगतान।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >12</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">नगर विकास विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=ODMjMTcwIzUjMjAxNg=="> 

                                

                                  

                               83/2016/1206/नौ-5-2016-193बजट/2015 </a><br /><span >21/09/2016  5:05PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >वि0वर्ष 2016-17 में मथुूरा स्थित गोकुल बैराज के डूब क्षेत्र से प्रभावित राजस्‍व ग्रामों में भूमि प्रतिकर के भुगतान हेतु धनराशि की स्‍वीकृति।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >13</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">राजस्‍व विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=NjMjMTc1IzEjMjAxNg=="> 

                                

                                  

                               63/2016/संख्या -1110/एक-1-2016-5(49)/2015 </a><br /><span >21/09/2016  5:00PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >ग्रेटर नोयडा औद्योगिक विकास प्राधिकरण के सुनियोजित विकास हेतु<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >14</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">राजस्‍व विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=NjIjMTc1IzEjMjAxNg=="> 

                                

                                  

                               62/2016/संख्या -1249/एक-1-2016-5(49)/2016 </a><br /><span >21/09/2016  4:55PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >ग्रेटर नोयडा औद्योगिक विकास प्राधिकरण के सुनियोजित विकास हेतु<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >15</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">नगर विकास विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=ODIjMTcwIzUjMjAxNg=="> 

                                

                                  

                               82/2016/1162/नौ-5-2016-79बजट/2015 </a><br /><span >21/09/2016  4:55PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >वित्‍तीय वर्ष 2015-16 में जनपद लखनऊ ट्रांस गोमती क्षेत्र में निशातगंज, गुलाचीन मन्दिर के पास जगरानी हास्पिटल से टेढ़ी पुलिया एवं अन्‍य से सीवर लाइन हेतु वित्‍तीय स्‍वीकृति।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >16</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">राजस्‍व विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=NjEjMTc1IzEjMjAxNg=="> 

                                

                                  

                               61/2016/संख्या - 1232/एक-1-2016-5(31)/2012 </a><br /><span >21/09/2016  4:52PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >इस्टयर्न डेडीकेटेड फ्रेंट कारीडोर रेल परियोजना हेतु रेलवे विभाग, भारत सरकार को उपलब्ध  करायी गयी भूमि 1.4522 हे0 को निरस्‍त करने विषयक<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >17</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">व्‍यवसायिक शिक्षा एवं कौशल विकास विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=Mjc0IzE4MCMxIzIwMTY="> 

                                

                                  

                               274/2016/3015/89-व्या 0शि0एवं कौ0वि0वि0-2015 </a><br /><span >21/09/2016  4:45PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >अनुसूचित जाति सब प्लाान के अन्तर्गत खोले गये राजकीय औद्योगिक प्रशिक्षण संस्थान, बबेरू-बांदा  के 	भवन 	निर्माण हेतु वित्तीय स्वीकृति।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >18</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">आवास विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=NSMxODYjNCMyMDE2"> 

                                

                                  

                               5/2016/स्‍मारक संग्रहालयों के सम्‍ब‍न्‍ध में। </a><br /><span >21/09/2016  4:36PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >स्मारकों, संग्रहालयों, संस्थाओं, पार्को व उपवनो आदि की प्रबन्धन सुरक्षा एवं अनुरक्षण 	समिति के कार्मिकों के वेतन-भत्तों के लिए धनराशि की स्वीकृति (वित्तीय वर्ष 2016-17) के संबंध 	में।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >19</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">कृषि विभाग</span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=MzIjMzcjMiMyMDE2"> 

                                

                                  

                               32/2016/2531/12-2-2016 </a><br /><span >21/09/2016  4:28PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >राज्य स्तरीय रबी उत्पा्दकता गोष्ठी, 2016 के आयोजन के सम्बन्ध में।<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                              <tr style="height:10%" >

                                                                                  <td style="width:3%; vertical-align:top;" class="style_border_top_left" >20</td>

                                                                                  <td style="width:47%;" valign="top" class="style_border_top_left"  ><span style="text-decoration:underline;">प्राविधिक शिक्षा विभाग </span><br /> <a target="_blank" name="myAnchor" style="color: Blue;"  

                                                                                    href="frmPDF.aspx?qry=NzkjMTIjMyMyMDE2"> 

                                

                                  

                               79/2016/1825/सोलह-3-2016-69(बी)/2015 </a><br /><span >21/09/2016  4:27PM</span></div></td>

                                                                                  <td style="width:50%" class="style_border_top_left" >राजकीय पालीटेक्निक, बस्ती् मे केन्द्रीवय सहायता से निर्माणाधीन 60 सीट्स महिला 	छात्रावास के निर्माण हेतु पुनरीक्षित लागत के सापेक्ष धनराशि स्वीरकृत किये जाने के संबंध मे<br />&nbsp;</td>

                                                                              </tr>



                                                                               

                                                                            

                                                                                     </table> 

                                                                                 </marquee>

                  

                                                                        </td>

        

                                                                    </tr>

                                                                 

                                                                </table>

                                                              

</div>

                                                            </td>

                                                           

                                                        </tr>

                                                        

                                                            <tr>

                                                                 

                                                                <td valign="top"  style="border-top:black 2px solid;border-left:black 2px solid;font-size:11px;">

                                                                    <table  width="100%" cellpadding="0" cellspacing="0" style="font-size:11px;">

                                                                         <tr style="height:8" >

                                                                        <td colspan="3" align="center" style="background-color: #017931;color:white; font-family:Verdana;font-size:13px;" >विभागवार जारी शासनादेश</td>

                                                                    </tr>

                                                                        <tr style="height:10">

                                                                            <td style="border: 1px solid red; background-color:#8B0707; color:white;  width:10% ;font-size:13px;" align="center">क्रसं</td>

                                                                            <td style="border: 1px solid red; background-color:#8B0707; color:white;  width:70%;font-size:13px;" align="center">विभाग का नाम</td>

                                                                            <td style="border: 1px solid red; background-color:#8B0707; color:white; width:20%;font-size:13px;" align="center">संख्या</td>

                                                                        </tr>

                                                                        <tr >

                                                                            <td colspan="3">

                                                                                <marquee behavior="scroll" bgcolor="white" direction="up"  style="height: 115pt;width:100%;"   scrolldelay="500" ONMOUSEOVER=this.stop()

            ONMOUSEOUT=this.start() > 

                                                                                     <table id="Table2" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse; vertical-align:top;height:100%;">

                                                                                    

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;1</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;अतिरिक्‍त ऊर्जा श्रोत विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;158</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;2</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;अल्‍पसंख्‍यक कल्‍याण विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;470</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;3</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;अवस्थापना विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;21</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;4</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;आबकारी विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;337</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;5</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;आवास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;721</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;6</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;उच्‍च शिक्षा विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;258</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;7</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;उत्‍तर प्रदेश पुनर्गठन समन्‍वय विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;18</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;8</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;उद्यान विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;273</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;9</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;उपभोक्‍ता संरक्षण एवं बाट माप विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;775</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;10</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;ऊर्जा विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;320</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;11</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;एन.आर.आई  विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;12</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;औद्योगिक विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;266</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;13</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;कृषि विपणन एवं विदेश व्‍यापार विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;128</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;14</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;कृषि विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;388</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;15</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;कृषि शिक्षा एवं अनुसंधान विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;90</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;16</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;कार्मिक विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;807</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;17</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;कार्यक्रम कार्यान्वयन विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;33</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;18</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;कारागार प्रशासन एवं सुधार विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1668</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;19</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;खेल विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;179</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;20</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;खाद्य एवं औषधि प्रशासन विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;270</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;21</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;खाद्य एवम् रसद विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;2053</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;22</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;खादी एवं ग्रामोद्योग विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;121</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;23</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;ग्राम्य विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1249</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;24</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;ग्रामीण अभियन्‍त्रण विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;316</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;25</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;गृह विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1264</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;26</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;गोपन विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;5</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;27</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;चिकित्‍सा एवं स्‍वास्‍थ विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;2055</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;28</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;चिकित्‍सा शिक्षा एवं आयुष विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;821</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;29</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;चीनी उद्योग एवं गन्‍ना विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;148</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;30</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;दुग्ध विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;63</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;31</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;धर्मार्थ कार्य  </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;38</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;32</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;नगर विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1535</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;33</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;नगरीय रोजगार एवं गरीबी उन्‍मूलन विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1788</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;34</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;न्याय विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1041</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;35</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;नागरिक उड्ड़यन विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;193</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;36</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;नागरिक सुरक्षा विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;24</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;37</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;निजी पूंजी निवेश विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;0</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;38</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;नियुक्ति विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;611</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;39</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;नियोजन विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1042</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;40</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;निर्वाचन विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;42</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;41</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;पंचायतीराज विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;489</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;42</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;परती भूमि विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;37</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;43</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;पर्यटन विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;355</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;44</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;पर्यावरण विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;30</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;45</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;प्रशासनिक सुधार विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;170</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;46</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;प्राविधिक शिक्षा विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;550</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;47</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;परिवहन विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;484</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;48</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;प्रोटोकाल विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;150</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;49</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;पशुधन विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;318</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;50</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;पिछड़ा वर्ग कल्‍याण विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;97</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;51</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;बैकिंग विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;0</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;52</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;भूतत्‍व एवं खनिकर्म विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;65</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;53</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;भाषा विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;101</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;54</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;मुख्‍यमंत्री कार्यालय लोक शिकायत विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;18</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;55</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;मत्‍स्‍य विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;90</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;56</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;महिला एवं बाल विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;214</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;57</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;युवा कल्याण विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;17</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;58</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;रेशम विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;81</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;59</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;राजनैतिक पेंशन विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;92</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;60</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;राज्य योजना आयोग विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;61</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;61</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;राज्य सम्पत्ति</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1803</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;62</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;राजस्‍व विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;2065</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;63</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;राष्‍ट्रीय एकीकरण विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;68</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;64</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;लघु सिंचाई विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;450</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;65</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;लोक निर्माण विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;4928</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;66</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;लोक सेवा प्रबंधन विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;4</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;67</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;वन विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;881</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;68</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;व्‍यवसायिक शिक्षा एवं कौशल विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;676</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;69</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;वस्‍त्रोद्योग विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;88</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;70</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;वाहय साहायतिक परियोजना </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;27</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;71</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;विकलांग कल्याण विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;968</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;72</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;विज्ञान एवं प्रोद्योगिकी विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;116</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;73</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;वित्‍त विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1199</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;74</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;विधायी विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;2</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;75</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;श्रम विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;446</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;76</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;शिक्षा विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;1332</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;77</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सूक्ष्म,लघु एवं मध्यम उद्यम विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;121</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;78</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सूचना एवं प्रौद्योगिकी विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;441</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;79</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सूचना विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;43</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;80</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सचिवालय प्रशासन विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;390</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;81</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;स्टाम्प एवं रजिस्ट्रेशन विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;100</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;82</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सतर्कता विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;14</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;83</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सैनिक कल्‍याण विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;75</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;84</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;समग्र ग्राम्‍य विकास विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;15</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;85</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;समन्वय विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;26</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;86</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;समाज कल्याण विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;761</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;87</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;स्‍वतन्‍त्रता संग्राम सेनानी कल्‍याण परिषद विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;9</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;88</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;संस्‍थागत वित्‍त कर एवं निबन्‍धन विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;250</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;89</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;संसदीय विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;4</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;90</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सहकारिता  विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;106</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;91</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सामान्‍य प्रशासन विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;25</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;92</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सार्वजनिक उद्यम विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;59</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;93</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सांस्‍कृति विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;261</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;94</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;सिंचाई एवं जल संसाधन विभाग</td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;2807</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                         <tr  style="height:10%"  >

                                                                                  <td style="width:10%; vertical-align:top;" class="style_border_top_left" >&nbsp;95</td>

                                                                                  <td style="width:70%;" valign="top" class="style_border_top_left"  >&nbsp;होमगाडर्स विभाग </td>

                                                                                  <td style="width:20%" class="style_border_top_left" >&nbsp;185</td>

                                                                              </tr>

                                                                                

                                                                            

                                                                                </table></marquee> </td>

                                                                        </tr>

                                                                    </table>

                                                                </td>

                                                            </tr>

                                                      

                                                        

                                                    </table>

                                                   

                                                    </td>

                                                 

                                            </tr>



 <tr id="r1">

	<td colspan="2" width="100%">

   <div id="UpdatePanel2">

		

    

                                             

	</div>



  </td>

</tr>



                                        </table>

                                    </td>

                                </tr>

                            </table>



                        </td>

                    </tr>

                     

                </table>

        <div class="a">    

        <table style="width: 100%;font-family:Verdana;font-size:10px;">

        <tr>

         <td>

          <marquee   bgcolor="white"    behavior="alternate"  ONMOUSEOVER="this.stop()"  

            ONMOUSEOUT="this.start()" scrolldelay="300"    >

                                                                                 <table  >

                                                                              

                                                                              <tr   >

                                                                                 <td>

                                                                           <img  src="GO/images/new.gif"/>     <a target="_blank"  style="color: Blue;font-size:14px"  

                                                                                    href="HEmail.aspx">शासनादेशों की दैनिक सूची प्राप्त करने हेतु क्लिक करे</a> <img  src="GO/images/new.gif"/>

                                                                                   </td>  <td> <a target="_blank"  style="color: Blue;;font-size:14px"  

                                                                                    href="eemail.aspx"> Click here to subscribe for Shasanadesh Daily Summary Subscription Service </a> <img  src="GO/images/new.gif"/>

                                                                             </td>

                                                                              </tr>

                                                                              <tr   >

                                                                                 

                                                                             <td  colspan="2" align="center"><img  src="GO/images/new.gif"/>

                                                                           <a target="_blank"  style="color: Blue;font-size:14px"  

                                                                                    href="GO/missingGoH.aspx">01 जनवरी 2015 के बाद जारी महत्वपूर्ण/नीतिगत शासनादेश जो ऑनलाइन जारी न हुए हो, उनके सम्बन्ध में सूचित करें।</a><img  src="GO/images/new.gif"/>

                                                                             </td> 

                                                                              </tr>

                                                                               

                                                                                                      </table></marquee>

             </td>

        </tr>

        <tr>

		<td  align="center" class="border_all" style="background-color: #CCCCCC"> 

        <table ><tr><td class="hd3" align ="center" >

		    This Website is designed, developed &amp; hosted by, National Informatics Centre, UP 

            State Unit Lucknow.<br />

            Best viewed in 1024x768 pixels resolution and ie 9 and 

            above. 

            



                    </td></tr>

            <tr><td class="hd3" align="center">

           

	        Information is provided &amp; updated by the Secretariat Administration Department, 

                Govt. of UP . For any Query regarding this website, Please contact the &quot;Web 

                Information Manager: Mr. Raj Kumar Singh, Special Secretary, SAD, Govt. of UP at Ph. 

                No. 2213458.<br />

                Responsibility of the content of the website will be of the department 

                Concerned. This is applicable for all the pages of this site.</td></tr>

                <tr><td  align="center" class="hd3">

          

           </td></tr></table> 

		</td>

		</tr>

        </table>

        </div>

               

    </div>

    

<script type="text/javascript">

//<![CDATA[

var Page_Validators =  new Array(document.getElementById("RegularExpressionValidator1"), document.getElementById("RegularExpressionValidator2"), document.getElementById("RegularExpressionValidator3"));

//]]>

</script>



<script type="text/javascript">

//<![CDATA[

var RegularExpressionValidator1 = document.all ? document.all["RegularExpressionValidator1"] : document.getElementById("RegularExpressionValidator1");

RegularExpressionValidator1.controltovalidate = "txtGOdate";

RegularExpressionValidator1.focusOnError = "t";

RegularExpressionValidator1.errormessage = "क़ृपया कब से तिथि dd/mm/yyyy में भरें ।  ";

RegularExpressionValidator1.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";

RegularExpressionValidator1.validationexpression = "^(((((0[1-9])|(1\\d)|(2[0-8]))/((0[1-9])|(1[0-2])))|((31/((0[13578])|(1[02])))|((29|30)/((0[1,3-9])|(1[0-2])))))/((20[0-9][0-9]))|((((0[1-9])|(1\\d)|(2[0-8]))/((0[1-9])|(1[0-2])))|((31/((0[13578])|(1[02])))|((29|30)/((0[1,3-9])|(1[0-2])))))/((19[0-9][0-9]))|(29/02/20(([02468][048])|([13579][26])))|(29/02/19(([02468][048])|([13579][26]))))$";

var RegularExpressionValidator2 = document.all ? document.all["RegularExpressionValidator2"] : document.getElementById("RegularExpressionValidator2");

RegularExpressionValidator2.controltovalidate = "txtGOdate0";

RegularExpressionValidator2.focusOnError = "t";

RegularExpressionValidator2.errormessage = "क़ृपया कब तक तिथि dd/mm/yyyy में भरें ।  ";

RegularExpressionValidator2.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";

RegularExpressionValidator2.validationexpression = "^(((((0[1-9])|(1\\d)|(2[0-8]))/((0[1-9])|(1[0-2])))|((31/((0[13578])|(1[02])))|((29|30)/((0[1,3-9])|(1[0-2])))))/((20[0-9][0-9]))|((((0[1-9])|(1\\d)|(2[0-8]))/((0[1-9])|(1[0-2])))|((31/((0[13578])|(1[02])))|((29|30)/((0[1,3-9])|(1[0-2])))))/((19[0-9][0-9]))|(29/02/20(([02468][048])|([13579][26])))|(29/02/19(([02468][048])|([13579][26]))))$";

var RegularExpressionValidator3 = document.all ? document.all["RegularExpressionValidator3"] : document.getElementById("RegularExpressionValidator3");

RegularExpressionValidator3.controltovalidate = "txtGOid";

RegularExpressionValidator3.errormessage = "कृपया हिंदी व् अंग्रेजी में ही लिखें";

RegularExpressionValidator3.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";

RegularExpressionValidator3.validationexpression = "^[A-Za-z\\u0900-\\u097F\\u200D0-9@_/# ,.\\r\\n\\t-:]+$";

//]]>

</script>





<script type="text/javascript">

//<![CDATA[



var Page_ValidationActive = false;

if (typeof(ValidatorOnLoad) == "function") {

    ValidatorOnLoad();

}



function ValidatorOnSubmit() {

    if (Page_ValidationActive) {

        return ValidatorCommonOnSubmit();

    }

    else {

        return true;

    }

}

        WebForm_AutoFocus('ddldept');Sys.Application.add_init(function() {

    $create(Sys.UI._Timer, {"enabled":true,"interval":90000,"uniqueID":"UpdateTimer"}, null, null, $get("UpdateTimer"));

});

Sys.Application.add_init(function() {

    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":"UpdatePanel1","displayAfter":500,"dynamicLayout":true}, null, null, $get("UpdateProgress1"));

});



document.getElementById('RegularExpressionValidator1').dispose = function() {

    Array.remove(Page_Validators, document.getElementById('RegularExpressionValidator1'));

}



document.getElementById('RegularExpressionValidator2').dispose = function() {

    Array.remove(Page_Validators, document.getElementById('RegularExpressionValidator2'));

}



document.getElementById('RegularExpressionValidator3').dispose = function() {

    Array.remove(Page_Validators, document.getElementById('RegularExpressionValidator3'));

}

//]]>

</script>

</form>

</body>

</html>

